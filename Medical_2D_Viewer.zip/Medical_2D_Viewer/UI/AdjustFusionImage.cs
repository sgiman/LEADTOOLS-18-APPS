using System;
using System.Drawing;
using System.Windows.Forms;

using Leadtools.MedicalViewer;
using System.Collections.Generic;

namespace MedicalViewerDemo
{
    public partial class AdjustFusionImage : Form
    {
        MedicalViewer _viewer;
        MainForm _form;
        List<String>[] _cellFusionNames;
        MedicalViewerMultiCell _cell;
        bool _update;

        public AdjustFusionImage()
        {
            InitializeComponent();
        }

        public AdjustFusionImage(MedicalViewer viewer, MainForm form)
        {
            _viewer = viewer;
            _form = form;

            InitializeComponent();

            int cellIndex = _form.GetFirstSelectedMultiCellIndex();

            if (cellIndex == -1)
                return;

            _cell = (MedicalViewerMultiCell)_viewer.Cells[cellIndex];
            if (_cell == null)
                return;

            _cellFusionNames = _form.FusionListNames[cellIndex];

            UpdateFusionUI(0);

            UpdateFusionComboBox();

        }

        private void UpdateFusionComboBox()
        {
            _cmbFusedIndex.Items.Clear();

            int subCellIndex = _cell.ActiveSubCell;

            int index = 0;
            int length = _cellFusionNames[subCellIndex] == null ? 0 : _cellFusionNames[subCellIndex].Count;

            for (index = 0; index < length; index++)
            {
                _cmbFusedIndex.Items.Add(_cellFusionNames[subCellIndex][index]);
            }

            EnableControls(length != 0);

            if (length != 0)
            {
                _cmbFusedIndex.SelectedIndex = 0;
            }
        }

        private void EnableControls(bool enabled)
        {
            _txtWLWidth.Enabled =
            _txtWLCenter.Enabled =
            _txtOffsetX.Enabled =
            _txtOffsetY.Enabled = 
            _chkFit.Enabled = enabled;
            _txtScale.Enabled = (!_chkFit.Checked) && enabled;
        }

        private void UpdateFusion()
        {
#if LEADTOOLS_V175_OR_LATER
            if (!_update)
                return;

            int subCellIndex = _cell.ActiveSubCell;
            int index = _cmbFusedIndex.SelectedIndex;

            MedicalViewerFusion fusion = _cell.SubCells[subCellIndex].Fusion[index];

            if (_txtWLWidth.Text == "")
                fusion.Width = 1;
            else
                fusion.Width = Convert.ToInt32(_txtWLWidth.Text);

            if (_txtWLCenter.Text == "")
                fusion.Center = 0;
            else
                fusion.Center = Convert.ToInt32(_txtWLCenter.Text);
            fusion.ColorPalette = (MedicalViewerPaletteType)_cmbPalette.SelectedIndex;


            if (_txtOffsetX.Text == "")
                fusion.OffsetX = 0;
            else
                fusion.OffsetX = Convert.ToInt32(_txtOffsetX.Text);

            if (_txtOffsetY.Text == "")
                fusion.OffsetY = 0;
            else
                fusion.OffsetY = Convert.ToInt32(_txtOffsetY.Text);

            if (_txtScale.Text == "")
                fusion.Scale = 0;
            else
                fusion.Scale = _chkFit.Checked ? 0 : Convert.ToInt32(_txtScale.Text) / 100.0f;

            _cell.Invalidate();
#endif // LEADTOOLS_V175_OR_LATER
        }

        private void SuspendUpdate()
        {
            _update = false;
        }

        private void ResumeUpdate()
        {
            _update = true;
        }


        private void UpdateFusionUI(int index)
        {
            SuspendUpdate();
            int subCellIndex = _cell.ActiveSubCell;

            MedicalViewerFusion fusion = _cell.SubCells[subCellIndex].Fusion[index];

            _cmbPalette.SelectedIndex = (int)fusion.ColorPalette;
            _txtWLWidth.Text = fusion.Width.ToString();
            _txtWLCenter.Text = fusion.Center.ToString();


            _txtOffsetX.Text = fusion.OffsetX.ToString();
            _txtOffsetY.Text = fusion.OffsetY.ToString();

            _txtScale.Text = (fusion.Scale == 0) ? "100" : Convert.ToInt32(fusion.Scale * 100).ToString();
            _txtScale.Enabled = (fusion.Scale != 0);
            _chkFit.Checked = (fusion.Scale == 0);
            ResumeUpdate();
        }

        private void _btnOK_Click(object sender, EventArgs e)
        {
        }

        private void _btnApply_Click(object sender, EventArgs e)
        {
            _btnOK_Click(sender, e);
        }

        private void _txtOffsetY_TextChanged(object sender, EventArgs e)
        {
            UpdateFusion();
        }

        private void _txtOffsetX_TextChanged(object sender, EventArgs e)
        {
            UpdateFusion();
        }

        private void _txtScale_TextChanged(object sender, EventArgs e)
        {
            UpdateFusion();
        }

        private void _txtWLWidth_TextChanged(object sender, EventArgs e)
        {
            UpdateFusion();
        }

        private void _txtWLCenter_TextChanged(object sender, EventArgs e)
        {
            UpdateFusion();
        }

        private void _chkFit_CheckedChanged(object sender, EventArgs e)
        {
            _txtScale.Enabled = !_chkFit.Checked;
            UpdateFusion();
        }

        private void _cmbFusedIndex_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateFusionUI(_cmbFusedIndex.SelectedIndex);
        }

        private void _cmbPalette_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateFusion();
        }
    }
}
