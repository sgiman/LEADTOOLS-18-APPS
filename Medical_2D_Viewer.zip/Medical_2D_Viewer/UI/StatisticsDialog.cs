using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Leadtools.MedicalViewer;

namespace MedicalViewerDemo
{
   public partial class StatisticsDialog : Form
   {
      MedicalViewer _viewer;
      MedicalViewerMultiCell cell = null;

      public StatisticsDialog(MainForm owner)
      {
         int index;

         InitializeComponent();

         int cellIndex = owner.SearchForFirstSelected();

         if (cellIndex != -1)
            cell = (MedicalViewerMultiCell)owner.Viewer.Cells[cellIndex];

         for (index = 0; index < owner.Viewer.Cells.Count; ++index)
            _cmbCellIndex.Items.Add(index.ToString());

         _viewer = owner.Viewer;
         if (_viewer.Cells.Count != 0)
            _cmbCellIndex.SelectedIndex = 0;
         else
            _cmbCellIndex.Enabled = false;

         _txtCellCount.Text = owner.Viewer.Cells.Count.ToString();
         if (cell != null)
            _txtActionCount.Text = cell.ActionCount.ToString();
         _txtViewerLeft.Text = owner.Viewer.Location.X.ToString();
         _txtViewerTop.Text = owner.Viewer.Location.Y.ToString();
         _txtViewerRight.Text = owner.Viewer.Size.Width.ToString();
         _txtViewerBottom.Text = owner.Viewer.Size.Height.ToString();
      }

      private void okButton_Click(object sender, EventArgs e)
      {
         this.Close();
      }

      private void _cmbCellIndex_SelectedIndexChanged(object sender, EventArgs e)
      {
         _txtCellLeft.Text = _viewer.Cells[_cmbCellIndex.SelectedIndex].Location.X.ToString();
         _txtCellTop.Text = _viewer.Cells[_cmbCellIndex.SelectedIndex].Location.Y.ToString();
         _txtCellRight.Text = _viewer.Cells[_cmbCellIndex.SelectedIndex].Size.Width.ToString();
         _txtCellBottom.Text = _viewer.Cells[_cmbCellIndex.SelectedIndex].Size.Height.ToString();

         _txtFrozen.Text = ((MedicalViewerCell)_viewer.Cells[_cmbCellIndex.SelectedIndex]).Frozen.ToString();
         _txtSelected.Text = ((MedicalViewerCell)_viewer.Cells[_cmbCellIndex.SelectedIndex]).Selected.ToString();
      }
   }
}