namespace MedicalViewerDemo
{
   partial class StatisticsDialog
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this._txtViewerLeft = new System.Windows.Forms.Label();
         this._txtViewerBottom = new System.Windows.Forms.Label();
         this._txtViewerRight = new System.Windows.Forms.Label();
         this._txtViewerTop = new System.Windows.Forms.Label();
         this._txtCellCount = new System.Windows.Forms.Label();
         this._txtActionCount = new System.Windows.Forms.Label();
         this._cmbCellIndex = new System.Windows.Forms.ComboBox();
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.label17 = new System.Windows.Forms.Label();
         this.label16 = new System.Windows.Forms.Label();
         this.label15 = new System.Windows.Forms.Label();
         this.groupBox2 = new System.Windows.Forms.GroupBox();
         this._txtFrozen = new System.Windows.Forms.Label();
         this._txtSelected = new System.Windows.Forms.Label();
         this._txtCellTop = new System.Windows.Forms.Label();
         this.label19 = new System.Windows.Forms.Label();
         this._txtCellRight = new System.Windows.Forms.Label();
         this.label18 = new System.Windows.Forms.Label();
         this._txtCellBottom = new System.Windows.Forms.Label();
         this.label20 = new System.Windows.Forms.Label();
         this._txtCellLeft = new System.Windows.Forms.Label();
         this.label21 = new System.Windows.Forms.Label();
         this._btnOK = new System.Windows.Forms.Button();
         this.groupBox1.SuspendLayout();
         this.groupBox2.SuspendLayout();
         this.SuspendLayout();
         // 
         // _txtViewerLeft
         // 
         this._txtViewerLeft.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this._txtViewerLeft.Location = new System.Drawing.Point(98, 16);
         this._txtViewerLeft.Name = "_txtViewerLeft";
         this._txtViewerLeft.Size = new System.Drawing.Size(37, 22);
         this._txtViewerLeft.TabIndex = 0;
         // 
         // _txtViewerBottom
         // 
         this._txtViewerBottom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this._txtViewerBottom.Location = new System.Drawing.Point(226, 16);
         this._txtViewerBottom.Name = "_txtViewerBottom";
         this._txtViewerBottom.Size = new System.Drawing.Size(37, 22);
         this._txtViewerBottom.TabIndex = 1;
         // 
         // _txtViewerRight
         // 
         this._txtViewerRight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this._txtViewerRight.Location = new System.Drawing.Point(184, 16);
         this._txtViewerRight.Name = "_txtViewerRight";
         this._txtViewerRight.Size = new System.Drawing.Size(37, 22);
         this._txtViewerRight.TabIndex = 2;
         // 
         // _txtViewerTop
         // 
         this._txtViewerTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this._txtViewerTop.Location = new System.Drawing.Point(142, 16);
         this._txtViewerTop.Name = "_txtViewerTop";
         this._txtViewerTop.Size = new System.Drawing.Size(37, 22);
         this._txtViewerTop.TabIndex = 3;
         // 
         // _txtCellCount
         // 
         this._txtCellCount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this._txtCellCount.Location = new System.Drawing.Point(98, 47);
         this._txtCellCount.Name = "_txtCellCount";
         this._txtCellCount.Size = new System.Drawing.Size(37, 22);
         this._txtCellCount.TabIndex = 4;
         // 
         // _txtActionCount
         // 
         this._txtActionCount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this._txtActionCount.Location = new System.Drawing.Point(98, 82);
         this._txtActionCount.Name = "_txtActionCount";
         this._txtActionCount.Size = new System.Drawing.Size(37, 22);
         this._txtActionCount.TabIndex = 5;
         // 
         // _cmbCellIndex
         // 
         this._cmbCellIndex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this._cmbCellIndex.FormattingEnabled = true;
         this._cmbCellIndex.Location = new System.Drawing.Point(93, 30);
         this._cmbCellIndex.Name = "_cmbCellIndex";
         this._cmbCellIndex.Size = new System.Drawing.Size(71, 21);
         this._cmbCellIndex.TabIndex = 14;
         this._cmbCellIndex.SelectedIndexChanged += new System.EventHandler(this._cmbCellIndex_SelectedIndexChanged);
         // 
         // groupBox1
         // 
         this.groupBox1.Controls.Add(this.label17);
         this.groupBox1.Controls.Add(this.label16);
         this.groupBox1.Controls.Add(this.label15);
         this.groupBox1.Controls.Add(this._txtActionCount);
         this.groupBox1.Controls.Add(this._txtCellCount);
         this.groupBox1.Controls.Add(this._txtViewerTop);
         this.groupBox1.Controls.Add(this._txtViewerRight);
         this.groupBox1.Controls.Add(this._txtViewerBottom);
         this.groupBox1.Controls.Add(this._txtViewerLeft);
         this.groupBox1.Location = new System.Drawing.Point(7, 5);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(272, 112);
         this.groupBox1.TabIndex = 15;
         this.groupBox1.TabStop = false;
         this.groupBox1.Text = "General Properties";
         // 
         // label17
         // 
         this.label17.AutoSize = true;
         this.label17.Location = new System.Drawing.Point(17, 52);
         this.label17.Name = "label17";
         this.label17.Size = new System.Drawing.Size(54, 13);
         this.label17.TabIndex = 8;
         this.label17.Text = "Cell count";
         // 
         // label16
         // 
         this.label16.AutoSize = true;
         this.label16.Location = new System.Drawing.Point(15, 86);
         this.label16.Name = "label16";
         this.label16.Size = new System.Drawing.Size(67, 13);
         this.label16.TabIndex = 7;
         this.label16.Text = "Action count";
         // 
         // label15
         // 
         this.label15.AutoSize = true;
         this.label15.Location = new System.Drawing.Point(1, 21);
         this.label15.Name = "label15";
         this.label15.Size = new System.Drawing.Size(95, 13);
         this.label15.TabIndex = 6;
         this.label15.Text = "Viewer Boundaries";
         // 
         // groupBox2
         // 
         this.groupBox2.Controls.Add(this._txtFrozen);
         this.groupBox2.Controls.Add(this._txtSelected);
         this.groupBox2.Controls.Add(this._txtCellTop);
         this.groupBox2.Controls.Add(this.label19);
         this.groupBox2.Controls.Add(this._txtCellRight);
         this.groupBox2.Controls.Add(this.label18);
         this.groupBox2.Controls.Add(this._txtCellBottom);
         this.groupBox2.Controls.Add(this.label20);
         this.groupBox2.Controls.Add(this._txtCellLeft);
         this.groupBox2.Controls.Add(this.label21);
         this.groupBox2.Controls.Add(this._cmbCellIndex);
         this.groupBox2.Location = new System.Drawing.Point(9, 121);
         this.groupBox2.Name = "groupBox2";
         this.groupBox2.Size = new System.Drawing.Size(270, 181);
         this.groupBox2.TabIndex = 16;
         this.groupBox2.TabStop = false;
         this.groupBox2.Text = "&Cell Properties";
         // 
         // _txtFrozen
         // 
         this._txtFrozen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this._txtFrozen.Location = new System.Drawing.Point(93, 127);
         this._txtFrozen.Name = "_txtFrozen";
         this._txtFrozen.Size = new System.Drawing.Size(37, 22);
         this._txtFrozen.TabIndex = 14;
         // 
         // _txtSelected
         // 
         this._txtSelected.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this._txtSelected.Location = new System.Drawing.Point(93, 92);
         this._txtSelected.Name = "_txtSelected";
         this._txtSelected.Size = new System.Drawing.Size(37, 22);
         this._txtSelected.TabIndex = 13;
         // 
         // _txtCellTop
         // 
         this._txtCellTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this._txtCellTop.Location = new System.Drawing.Point(137, 61);
         this._txtCellTop.Name = "_txtCellTop";
         this._txtCellTop.Size = new System.Drawing.Size(37, 22);
         this._txtCellTop.TabIndex = 12;
         // 
         // label19
         // 
         this.label19.AutoSize = true;
         this.label19.Location = new System.Drawing.Point(21, 96);
         this.label19.Name = "label19";
         this.label19.Size = new System.Drawing.Size(48, 13);
         this.label19.TabIndex = 11;
         this.label19.Text = "Selected";
         // 
         // _txtCellRight
         // 
         this._txtCellRight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this._txtCellRight.Location = new System.Drawing.Point(179, 61);
         this._txtCellRight.Name = "_txtCellRight";
         this._txtCellRight.Size = new System.Drawing.Size(37, 22);
         this._txtCellRight.TabIndex = 11;
         // 
         // label18
         // 
         this.label18.AutoSize = true;
         this.label18.Location = new System.Drawing.Point(16, 35);
         this.label18.Name = "label18";
         this.label18.Size = new System.Drawing.Size(53, 13);
         this.label18.TabIndex = 15;
         this.label18.Text = "Cell index";
         // 
         // _txtCellBottom
         // 
         this._txtCellBottom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this._txtCellBottom.Location = new System.Drawing.Point(221, 61);
         this._txtCellBottom.Name = "_txtCellBottom";
         this._txtCellBottom.Size = new System.Drawing.Size(37, 22);
         this._txtCellBottom.TabIndex = 10;
         // 
         // label20
         // 
         this.label20.AutoSize = true;
         this.label20.Location = new System.Drawing.Point(25, 130);
         this.label20.Name = "label20";
         this.label20.Size = new System.Drawing.Size(40, 13);
         this.label20.TabIndex = 10;
         this.label20.Text = "Frozen";
         // 
         // _txtCellLeft
         // 
         this._txtCellLeft.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this._txtCellLeft.Location = new System.Drawing.Point(93, 61);
         this._txtCellLeft.Name = "_txtCellLeft";
         this._txtCellLeft.Size = new System.Drawing.Size(37, 22);
         this._txtCellLeft.TabIndex = 9;
         // 
         // label21
         // 
         this.label21.AutoSize = true;
         this.label21.Location = new System.Drawing.Point(6, 66);
         this.label21.Name = "label21";
         this.label21.Size = new System.Drawing.Size(87, 13);
         this.label21.TabIndex = 9;
         this.label21.Text = "Cell\'s boundaries";
         // 
         // _btnOK
         // 
         this._btnOK.DialogResult = System.Windows.Forms.DialogResult.Cancel;
         this._btnOK.Location = new System.Drawing.Point(110, 308);
         this._btnOK.Name = "_btnOK";
         this._btnOK.Size = new System.Drawing.Size(72, 29);
         this._btnOK.TabIndex = 17;
         this._btnOK.Text = "&OK";
         this._btnOK.UseVisualStyleBackColor = true;
         this._btnOK.Click += new System.EventHandler(this.okButton_Click);
         // 
         // StatisticsDialog
         // 
         this.AcceptButton = this._btnOK;
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.CancelButton = this._btnOK;
         this.ClientSize = new System.Drawing.Size(287, 342);
         this.Controls.Add(this._btnOK);
         this.Controls.Add(this.groupBox2);
         this.Controls.Add(this.groupBox1);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "StatisticsDialog";
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
         this.Text = "Statistics";
         this.groupBox1.ResumeLayout(false);
         this.groupBox1.PerformLayout();
         this.groupBox2.ResumeLayout(false);
         this.groupBox2.PerformLayout();
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.Label _txtViewerLeft;
      private System.Windows.Forms.Label _txtViewerBottom;
      private System.Windows.Forms.Label _txtViewerRight;
      private System.Windows.Forms.Label _txtViewerTop;
      private System.Windows.Forms.Label _txtCellCount;
      private System.Windows.Forms.Label _txtActionCount;
      private System.Windows.Forms.ComboBox _cmbCellIndex;
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.Label label17;
      private System.Windows.Forms.Label label16;
      private System.Windows.Forms.Label label15;
      private System.Windows.Forms.GroupBox groupBox2;
      private System.Windows.Forms.Label label19;
      private System.Windows.Forms.Label label18;
      private System.Windows.Forms.Label label20;
      private System.Windows.Forms.Label label21;
      private System.Windows.Forms.Button _btnOK;
      private System.Windows.Forms.Label _txtFrozen;
      private System.Windows.Forms.Label _txtSelected;
      private System.Windows.Forms.Label _txtCellTop;
      private System.Windows.Forms.Label _txtCellRight;
      private System.Windows.Forms.Label _txtCellBottom;
      private System.Windows.Forms.Label _txtCellLeft;
   }
}