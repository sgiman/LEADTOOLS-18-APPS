namespace MedicalViewerDemo
{
    partial class AdjustFusionImage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._btnClose = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this._cmbFusedIndex = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this._cmbPalette = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this._chkFit = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this._txtOffsetY = new MedicalViewerDemo.NumericTextBox();
            this._txtOffsetX = new MedicalViewerDemo.NumericTextBox();
            this._txtScale = new MedicalViewerDemo.NumericTextBox();
            this._txtWLCenter = new MedicalViewerDemo.NumericTextBox();
            this._txtWLWidth = new MedicalViewerDemo.NumericTextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // _btnClose
            // 
            this._btnClose.DialogResult = System.Windows.Forms.DialogResult.OK;
            this._btnClose.Location = new System.Drawing.Point(250, 245);
            this._btnClose.Name = "_btnClose";
            this._btnClose.Size = new System.Drawing.Size(74, 26);
            this._btnClose.TabIndex = 16;
            this._btnClose.Text = "&Close";
            this._btnClose.UseVisualStyleBackColor = true;
            this._btnClose.Click += new System.EventHandler(this._btnOK_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this._cmbFusedIndex);
            this.groupBox1.Controls.Add(this._txtOffsetY);
            this.groupBox1.Controls.Add(this._txtOffsetX);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this._cmbPalette);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this._txtScale);
            this.groupBox1.Controls.Add(this._chkFit);
            this.groupBox1.Controls.Add(this._txtWLCenter);
            this.groupBox1.Controls.Add(this._txtWLWidth);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(10, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(314, 218);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "&Fusion Parameters";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Fused Image";
            // 
            // _cmbFusedIndex
            // 
            this._cmbFusedIndex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cmbFusedIndex.FormattingEnabled = true;
            this._cmbFusedIndex.Items.AddRange(new object[] {
            "None",
            "Cool",
            "CyanHot",
            "Fire",
            "ICA2",
            "Ice",
            "OrangeHot ",
            "RainbowRGB",
            "RedHot",
            "Spectrum"});
            this._cmbFusedIndex.Location = new System.Drawing.Point(115, 174);
            this._cmbFusedIndex.Name = "_cmbFusedIndex";
            this._cmbFusedIndex.Size = new System.Drawing.Size(129, 21);
            this._cmbFusedIndex.TabIndex = 16;
            this._cmbFusedIndex.SelectedIndexChanged += new System.EventHandler(this._cmbFusedIndex_SelectedIndexChanged);
            // 
            // _txtOffsetY
            // 
            this._txtOffsetY.Location = new System.Drawing.Point(193, 136);
            this._txtOffsetY.MaximumAllowed = 1000;
            this._txtOffsetY.MinimumAllowed = -1000;
            this._txtOffsetY.Name = "_txtOffsetY";
            this._txtOffsetY.Size = new System.Drawing.Size(51, 20);
            this._txtOffsetY.TabIndex = 15;
            this._txtOffsetY.Text = "1";
            this._txtOffsetY.Value = 1;
            this._txtOffsetY.TextChanged += new System.EventHandler(this._txtOffsetY_TextChanged);
            // 
            // _txtOffsetX
            // 
            this._txtOffsetX.Location = new System.Drawing.Point(116, 136);
            this._txtOffsetX.MaximumAllowed = 1000;
            this._txtOffsetX.MinimumAllowed = -1000;
            this._txtOffsetX.Name = "_txtOffsetX";
            this._txtOffsetX.Size = new System.Drawing.Size(51, 20);
            this._txtOffsetX.TabIndex = 14;
            this._txtOffsetX.Text = "1";
            this._txtOffsetX.Value = 1;
            this._txtOffsetX.TextChanged += new System.EventHandler(this._txtOffsetX_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(63, 139);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Offset";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Palette";
            // 
            // _cmbPalette
            // 
            this._cmbPalette.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cmbPalette.FormattingEnabled = true;
            this._cmbPalette.Items.AddRange(new object[] {
            "None",
            "Cool",
            "CyanHot",
            "Fire",
            "ICA2",
            "Ice",
            "OrangeHot ",
            "RainbowRGB",
            "RedHot",
            "Spectrum"});
            this._cmbPalette.Location = new System.Drawing.Point(115, 65);
            this._cmbPalette.Name = "_cmbPalette";
            this._cmbPalette.Size = new System.Drawing.Size(129, 21);
            this._cmbPalette.TabIndex = 9;
            this._cmbPalette.SelectedIndexChanged += new System.EventHandler(this._cmbPalette_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Scale";
            // 
            // _txtScale
            // 
            this._txtScale.Location = new System.Drawing.Point(116, 97);
            this._txtScale.MaximumAllowed = 1000;
            this._txtScale.MinimumAllowed = 1;
            this._txtScale.Name = "_txtScale";
            this._txtScale.Size = new System.Drawing.Size(51, 20);
            this._txtScale.TabIndex = 7;
            this._txtScale.Text = "1";
            this._txtScale.Value = 1;
            this._txtScale.TextChanged += new System.EventHandler(this._txtScale_TextChanged);
            // 
            // _chkFit
            // 
            this._chkFit.AutoSize = true;
            this._chkFit.Location = new System.Drawing.Point(186, 98);
            this._chkFit.Name = "_chkFit";
            this._chkFit.Size = new System.Drawing.Size(37, 17);
            this._chkFit.TabIndex = 6;
            this._chkFit.Text = "&Fit";
            this._chkFit.UseVisualStyleBackColor = true;
            this._chkFit.CheckedChanged += new System.EventHandler(this._chkFit_CheckedChanged);
            // 
            // _txtWLCenter
            // 
            this._txtWLCenter.Location = new System.Drawing.Point(193, 33);
            this._txtWLCenter.MaximumAllowed = 65535;
            this._txtWLCenter.MinimumAllowed = -65535;
            this._txtWLCenter.Name = "_txtWLCenter";
            this._txtWLCenter.Size = new System.Drawing.Size(51, 20);
            this._txtWLCenter.TabIndex = 4;
            this._txtWLCenter.Text = "1";
            this._txtWLCenter.Value = 1;
            this._txtWLCenter.TextChanged += new System.EventHandler(this._txtWLCenter_TextChanged);
            // 
            // _txtWLWidth
            // 
            this._txtWLWidth.Location = new System.Drawing.Point(116, 33);
            this._txtWLWidth.MaximumAllowed = 65535;
            this._txtWLWidth.MinimumAllowed = 0;
            this._txtWLWidth.Name = "_txtWLWidth";
            this._txtWLWidth.Size = new System.Drawing.Size(51, 20);
            this._txtWLWidth.TabIndex = 3;
            this._txtWLWidth.Text = "1";
            this._txtWLWidth.Value = 1;
            this._txtWLWidth.TextChanged += new System.EventHandler(this._txtWLWidth_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Window Level";
            // 
            // AdjustFusionImage
            // 
            this.AcceptButton = this._btnClose;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 285);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this._btnClose);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AdjustFusionImage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Fusion Properties";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button _btnClose;
       private System.Windows.Forms.GroupBox groupBox1;
      private NumericTextBox _txtWLCenter;
       private NumericTextBox _txtWLWidth;
       private System.Windows.Forms.Label label1;
       private System.Windows.Forms.Label label3;
       private System.Windows.Forms.ComboBox _cmbPalette;
       private System.Windows.Forms.Label label2;
       private NumericTextBox _txtScale;
       private System.Windows.Forms.CheckBox _chkFit;
       private NumericTextBox _txtOffsetY;
       private NumericTextBox _txtOffsetX;
       private System.Windows.Forms.Label label5;
       private System.Windows.Forms.Label label4;
       private System.Windows.Forms.ComboBox _cmbFusedIndex;
    }
}