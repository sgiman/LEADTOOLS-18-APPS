using System;
using System.Drawing;
using System.Windows.Forms;

using Leadtools.MedicalViewer;
using Leadtools;
using System.Collections.Generic;

namespace MedicalViewerDemo
{
   public partial class AddFusionImage : Form
   {
      MedicalViewer _viewer;
      MainForm _form;
      List<int> _weightList;
      List<RasterImage> _images;
      List<String>[] _cellFusionNames;
      MedicalViewerMultiCell _cell = null;

      public AddFusionImage()
      {
         InitializeComponent();
      }

      public AddFusionImage(MedicalViewer viewer, MainForm form)
      {
         _viewer = viewer;
         _form = form;
         _weightList = new List<int>();
         _images = new List<RasterImage>();

         InitializeComponent();
         InitializeFusionList();
         UpdateUI();

         if (_listFusionImages.Items.Count != 0)
         {
             _listFusionImages.SelectedIndex = 0;
             UpdateText();
         }

      }

      private void _btnOK_Click(object sender, EventArgs e)
      {
          if (ApplyFusion())
              this.Close();
      }

      private bool ApplyFusion()
      {
#if LEADTOOLS_V175_OR_LATER
          if (GetTotalCount() > 100)
          {
              MessageBox.Show("the weight total for the fused images should not exceed 100", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
              return false;
          }
          else
          {

              int cellIndex = _form.GetFirstSelectedMultiCellIndex();

              if (cellIndex == -1)
                  return false;

              MedicalViewerMultiCell cell = (MedicalViewerMultiCell)_viewer.Cells[cellIndex];
              if (cell == null)
                  return false;

              _cellFusionNames = _form.FusionListNames[cellIndex];

              int subCellIndex = cell.ActiveSubCell;

              if (_form.FusionListNames[cellIndex][subCellIndex] == null)
                  _form.FusionListNames[cellIndex][subCellIndex] = new List<String>();



              int index = 0;

              _form.FusionListNames[cellIndex][subCellIndex].Clear();

              for (index = 0; index < _listFusionImages.Items.Count; index++)
              {
                  _form.FusionListNames[cellIndex][subCellIndex].Add(_listFusionImages.Items[index].ToString());
              }
          }

#endif //LEADTOOLS_V175_OR_LATER
          return true;
      }

      private void InitializeFusionList()
      {
          int cellIndex = _form.GetFirstSelectedMultiCellIndex();

          if (cellIndex == -1)
              return;

          _cell = (MedicalViewerMultiCell)_viewer.Cells[cellIndex];
          if (_cell == null)
              return;

          _cellFusionNames = _form.FusionListNames[cellIndex];

          int subCellIndex = _cell.ActiveSubCell;

          if (_cellFusionNames[subCellIndex] == null)
              return;

          int index = 0;

          for (index = 0; index < _cellFusionNames[subCellIndex].Count; index++)
          {
              _listFusionImages.Items.Add(_cellFusionNames[subCellIndex][index]);
              _weightList.Add((int)(_cell.SubCells[subCellIndex].Fusion[index].FusionScale * 100));
              _images.Add(_cell.SubCells[subCellIndex].Fusion[index].FusedImage);
          }
      }

      private void _btnApply_Click(object sender, EventArgs e)
      {
          ApplyFusion();
      }

      private void _btnAdd_Click(object sender, EventArgs e)
      {
#if LEADTOOLS_V175_OR_LATER
          string seriesName = "";
          RasterImage image = _form.LoadFusionDicom(out seriesName);
          if (image == null)
              return;

          _listFusionImages.Items.Add(seriesName);
          _weightList.Add(_listFusionImages.Items.Count == 1 ? 50 : /*GetFusionDefaultValue()*/0);

          int index = _listFusionImages.Items.Count - 1;

          MedicalViewerFusion fusion = new MedicalViewerFusion();
          fusion.FusedImage = image;
          fusion.FusionScale = _weightList[index] / 100.0f;
          _images.Add(image);

          _cell.SubCells[_cell.ActiveSubCell].Fusion.Add(fusion);

          _listFusionImages.SelectedIndex = index;

          UpdateText();
          UpdateUI();
#endif //LEADTOOLS_V175_OR_LATER
      }

       private void UpdateUI()
       {
           _btnRemove.Enabled =
           _txtWeight.Enabled =
           _trackBarWeight.Enabled = _listFusionImages.Items.Count != 0;
       }

      private int GetTotalCount()
      {
          int count = 0;
          foreach (int weight in _weightList)
          {
              count += weight;
          }

          return count;

      }

      private int GetFusionDefaultValue()
      {
          double percentage = 0.0;
          double denominator = _listFusionImages.Items.Count + 1.0;

          double imagePercent = 100 - GetTotalCount();

          if (imagePercent < 0)
              return 0;

          percentage = imagePercent / denominator;

          foreach(int weight in _weightList)
          {
              percentage = percentage + (weight / denominator);
          }

          return (int)percentage;
      }

      private void UpdateFusion(int index)
      {

      }

      private void _btnRemove_Click(object sender, EventArgs e)
      {
#if LEADTOOLS_V175_OR_LATER
          int removeIndex = _listFusionImages.SelectedIndex;

          _cell.SubCells[_cell.ActiveSubCell].Fusion.RemoveAt(removeIndex);

          _listFusionImages.Items.RemoveAt(removeIndex);
          _weightList.RemoveAt(removeIndex);
          _images[removeIndex].Dispose();
          _images.RemoveAt(removeIndex);


          if (_listFusionImages.Items.Count != 0)
          {
              _listFusionImages.SelectedIndex = Math.Min(_listFusionImages.Items.Count - 1, removeIndex);
          }

          UpdateUI();
#endif //LEADTOOLS_V175_OR_LATER
      }

      private void _cmbSubCellIndex_SelectedIndexChanged(object sender, EventArgs e)
      {
      }

      private void UpdateText()
      {
          _txtWeight.Text = _weightList[_listFusionImages.SelectedIndex].ToString();
          _trackBarWeight.Value = _weightList[_listFusionImages.SelectedIndex];
      }

      private void _listFusionImages_SelectedIndexChanged(object sender, EventArgs e)
      {
          if (_listFusionImages.SelectedIndex != -1)
              UpdateText();
      }

      private void _txtWeight_TextChanged(object sender, EventArgs e)
      {
#if LEADTOOLS_V175_OR_LATER
          int index = _listFusionImages.SelectedIndex;
          if (index == -1)
              return;

          int Num;
          bool isNum = int.TryParse(_txtWeight.Text, out Num);

          if (!isNum)
          {
              _txtWeight.Text = _weightList[index].ToString();
          }
          else
          {
              if (_txtWeight.Text == "")
                  _weightList[index] = 0;
              else
                  _weightList[index] = Math.Min(100, Convert.ToInt32(_txtWeight.Text));

              _trackBarWeight.Value = _weightList[index];
              _cell.SubCells[_cell.ActiveSubCell].Fusion[index].FusionScale = _weightList[index] / 100.0f;
              _cell.Invalidate();
          }


#endif //LEADTOOLS_V175_OR_LATER

      }

      private void _trackBarWeight_Scroll(object sender, EventArgs e)
      {
          _txtWeight.Text = _trackBarWeight.Value.ToString();
      }
   }
}
