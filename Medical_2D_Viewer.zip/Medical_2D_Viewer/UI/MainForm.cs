using System;
using System.IO;
using System.Drawing;
using System.Drawing.Printing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.Threading;
using System.Collections.Generic;

using Leadtools;
using Leadtools.WinForms;
using Leadtools.Dicom;
using Leadtools.Codecs;
using Leadtools.Demos;
using Leadtools.ImageProcessing;
using Leadtools.MedicalViewer;
using Leadtools.ImageProcessing.Color;
using Leadtools.Annotations;

namespace MedicalViewerDemo
{
    public delegate void MyFunctionDelegate(MedicalViewerMultiCell cell, int subCellIndex);

    public partial class MainForm : Form
    {
        private List<List<String>[]> _fusionListNames;
        private int _images;
        private int _cellIndex;
        private MedicalViewer _medicalViewer;
        private bool _applyToAll;
        private PrintDocument _printDocument;
        private RasterImage _printImage;

        public PrintDocument PrintDocument
        {
            get
            {
                return _printDocument;
            }
        }


        public RasterImage PrintImage
        {
            get
            {
                return _printImage;
            }
            set
            {
                _printImage = value;
            }
        }

        public List<List<String>[]> FusionListNames
        {
            get
            {
                return _fusionListNames;
            }
        }


        public static MedicalViewerMultiCell _defaultCell;



        [STAThread]
        static void Main()
        {

/**************************************************************************************
#if LEADTOOLS_V175_OR_LATER
            Support.SetLicense();
#else
         Support.Unlock(false);
#endif // #if LEADTOOLS_V175_OR_LATER

         if (Support.KernelExpired)
                return;
***************************************************************************************/

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.EnableVisualStyles();
            Application.DoEvents();
            Application.Run(new MainForm());
        }



        public MainForm()
        {
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
            InitClass();
        }

        private void InitClass()
        {

            _fusionListNames = new List<List<String>[]>();
            CounterDialog counter = null;
            try
            {

                if (PrinterSettings.InstalledPrinters != null && PrinterSettings.InstalledPrinters.Count > 0)
                {
                    _printDocument = new PrintDocument();
                    _printDocument.BeginPrint += new PrintEventHandler(_printDocument_BeginPrint);
                    _printDocument.PrintPage += new PrintPageEventHandler(_printDocument_PrintPage);
                    _printDocument.EndPrint += new PrintEventHandler(_printDocument_EndPrint);
                }
                else
                    _printDocument = null;
            }
            catch (Exception)
            {
                _printDocument = null;
            }

            try
            {
                DicomEngine.Startup();

                using (RasterCodecs codecs = new RasterCodecs())
                {
                    RasterImage _image;
                    counter = new CounterDialog(this, codecs);
                    _applyToAll = false;

                    _medicalViewer = new MedicalViewer(1, 2);
                    _medicalViewer.Location = new Point(0, 0);
                    _medicalViewer.Size = new Size(this.ClientRectangle.Right, this.ClientRectangle.Bottom);

                    _mainPanel.Controls.Add(_medicalViewer);

                    DefaultImagesDialog defaultDialog = new DefaultImagesDialog();


                    if (defaultDialog.ShowDialog() == DialogResult.Yes)
                    {
                        counter.Show(this);
                        counter.Update();
                        _images = 2;

                        string imagesFolder;
#if LT_CLICKONCE
               imagesFolder = Application.StartupPath; 
#else
                        imagesFolder = DemosGlobal.ImagesFolder;
#endif // LT_CLICKONCE

                        string fileName = "../dicom/XA.DCM";
                        //string fileName = Path.Combine(imagesFolder, "xa.dcm");
                        if (File.Exists(fileName))
                        {
                            _image = codecs.Load(fileName);
                            if (_image != null)
                            {
                                MedicalViewerMultiCell cell = new MedicalViewerMultiCell(_image, false, 1, 1);
                                _medicalViewer.Cells.Add(cell);
                                _fusionListNames.Add(new List<String>[_image.PageCount]);

                                cell.Image = _image;
                                cell.ApplyActionOnMove = true;
#if LEADTOOLS_V16_OR_LATER
                                cell.SetScaleMode(MedicalViewerScaleMode.Fit);
#else
                     cell.FitImageToCell = true;
#endif
                                cell.SetTag(6, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.Scale);

                                cell.SetTag(2, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.UserData, "EX. ID 230-36-5448");
                                cell.SetTag(4, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.Frame);
                                cell.SetTag(2, MedicalViewerTagAlignment.BottomLeft, MedicalViewerTagType.WindowLevelData);
                                cell.SetTag(1, MedicalViewerTagAlignment.BottomLeft, MedicalViewerTagType.FieldOfView);
                                cell.SetTag(1, MedicalViewerTagAlignment.TopRight, MedicalViewerTagType.UserData, "Good, Guy");
                                cell.SetTag(2, MedicalViewerTagAlignment.TopRight, MedicalViewerTagType.UserData, "PID 125-98-445");
                                cell.SetTag(3, MedicalViewerTagAlignment.TopRight, MedicalViewerTagType.UserData, "DOB 08/02/1929");
                                cell.SetTag(5, MedicalViewerTagAlignment.TopRight, MedicalViewerTagType.UserData, "03/16/1999");
                                cell.SetTag(0, MedicalViewerTagAlignment.BottomLeft, MedicalViewerTagType.RulerUnit);
                                InitializeCell(cell);
                                InitializeEvents(cell);

                            }
                        }
                        
                        fileName = "../dicom/mr.dcm";
                        //fileName = Path.Combine(imagesFolder, "mr.dcm");

                        if (File.Exists(fileName))
                        {
                            _image = codecs.Load(fileName);

                            if (_image != null)
                            {
                                MedicalViewerMultiCell cell = new MedicalViewerMultiCell(_image, true, 1, 1);
                                _medicalViewer.Cells.Add(cell);
                                _fusionListNames.Add(new List<String>[_image.PageCount]);

                                cell.Image = _image;
                                cell.FitImageToCell = true;
                                cell.SetTag(1, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.UserData, "MRI");
                                cell.SetTag(2, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.UserData, "EX. ID G-1194-24");
                                cell.SetTag(4, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.Frame);
                                cell.SetTag(6, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.Scale);
                                cell.SetTag(2, MedicalViewerTagAlignment.BottomLeft, MedicalViewerTagType.WindowLevelData);
                                cell.SetTag(1, MedicalViewerTagAlignment.BottomLeft, MedicalViewerTagType.FieldOfView);
                                cell.SetTag(0, MedicalViewerTagAlignment.BottomLeft, MedicalViewerTagType.UserData, "THK 10 mm");
                                cell.SetTag(3, MedicalViewerTagAlignment.BottomLeft, MedicalViewerTagType.UserData, "TR 1333.33");
                                cell.SetTag(4, MedicalViewerTagAlignment.BottomLeft, MedicalViewerTagType.UserData, "TE 11.98");
                                cell.SetTag(6, MedicalViewerTagAlignment.BottomLeft, MedicalViewerTagType.UserData, "Comm longaxis - Normal");
                                cell.SetTag(0, MedicalViewerTagAlignment.TopRight, MedicalViewerTagType.UserData, "Community Hospital");
                                cell.SetTag(1, MedicalViewerTagAlignment.TopRight, MedicalViewerTagType.UserData, "Nice, Fellow");
                                cell.SetTag(2, MedicalViewerTagAlignment.TopRight, MedicalViewerTagType.UserData, "PID 123-45-6789");
                                cell.SetTag(3, MedicalViewerTagAlignment.TopRight, MedicalViewerTagType.UserData, "DOB 05/13/1936");
                                cell.SetTag(4, MedicalViewerTagAlignment.TopRight, MedicalViewerTagType.UserData, "Sex M");
                                cell.SetTag(5, MedicalViewerTagAlignment.TopRight, MedicalViewerTagType.UserData, "06/26/1995");
                                cell.Rows = 2;
                                cell.Columns = 2;
                                cell.ApplyActionOnMove = true;
                                InitializeCell(cell);
                                InitializeEvents(cell);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (counter != null)
                {
                    if (counter.Visible)
                        counter.Close();
                }
                MessageBox.Show(ex.Message, ex.Source);
            }
        }

        private void InitializeEvents(MedicalViewerMultiCell cell)
        {
#if LEADTOOLS_V175_OR_LATER
            cell.SpyGlassStarted += new EventHandler<MedicalViewerSpyGlassStartedEventArgs>(cell_SpyGlassStarted);
            cell.AnnotationCreated += new EventHandler<MedicalViewerAnnotationCreatedEventArgs>(cell_AnnotationCreated);
            cell.DeleteAnnotation += new EventHandler<MedicalViewerDeleteEventArgs>(cell_DeleteAnnotation);
            AddProbeToolEvents(cell);
#endif //LEADTOOLS_V175_OR_LATER
        }

        void cell_DeleteAnnotation(object sender, MedicalViewerDeleteEventArgs e)
        {
            ((MedicalViewerMultiCell)sender).RefreshAnnotation();
        }

        private static void InitializeCell(MedicalViewerCell cell)
        {
            cell.InteractiveInterpolation = true;

            Array enums = Enum.GetValues(typeof(MedicalViewerActionType));

            foreach (MedicalViewerActionType action in enums)
            {
                if (action != MedicalViewerActionType.None)
                {
                    if (cell.CanExecuteAction(action))
                        cell.AddAction(action);
                }
            }

            cell.SetAction(MedicalViewerActionType.WindowLevel, MedicalViewerMouseButtons.Left, MedicalViewerActionFlags.Active);
            cell.SetAction(MedicalViewerActionType.Offset, MedicalViewerMouseButtons.Right, MedicalViewerActionFlags.Active);
            cell.SetAction(MedicalViewerActionType.Scale, MedicalViewerMouseButtons.Middle, MedicalViewerActionFlags.Active);
            cell.SetAction(MedicalViewerActionType.Stack, MedicalViewerMouseButtons.Wheel, MedicalViewerActionFlags.Active);

            MedicalViewerKeys medicalKeys = new MedicalViewerKeys();
            medicalKeys.MouseDown = Keys.Down;
            medicalKeys.MouseUp = Keys.Up;
            medicalKeys.MouseLeft = Keys.Left;
            medicalKeys.MouseRight = Keys.Right;
            cell.SetActionKeys(MedicalViewerActionType.Offset, medicalKeys);
            medicalKeys.Modifiers = MedicalViewerModifiers.Ctrl;
            cell.SetActionKeys(MedicalViewerActionType.WindowLevel, medicalKeys);
            medicalKeys.Modifiers = MedicalViewerModifiers.None;
            medicalKeys.MouseDown = Keys.PageDown;
            medicalKeys.MouseUp = Keys.PageUp;
            cell.SetActionKeys(MedicalViewerActionType.Stack, medicalKeys);
            medicalKeys.MouseDown = Keys.Add;
            medicalKeys.MouseUp = Keys.Subtract;
            cell.SetActionKeys(MedicalViewerActionType.Scale, medicalKeys);

            MedicalViewerWindowLevel windowLevel = (MedicalViewerWindowLevel)(cell.GetActionProperties(MedicalViewerActionType.WindowLevel, 0));
            windowLevel.RelativeSensitivity = true;
            cell.SetActionProperties(MedicalViewerActionType.WindowLevel, windowLevel, 0);
            cell.AlwaysInterpolate = true;
            cell.CellBackColor = Color.Black;
        }

#if LEADTOOLS_V175_OR_LATER
        private void cell_SpyGlassStarted(object sender, MedicalViewerSpyGlassStartedEventArgs e)
        {
            MedicalViewer medicalViewer = this.Viewer;

            RasterImage image = e.Image;

            if (image.UseLookupTable)
            {
                RasterColor16[] colors = image.GetLookupTable16();
                int length = colors.Length;
                int counter;

                for (counter = 0; counter < length; counter++)
                {
                    colors[counter].R ^= 0xffff;
                    colors[counter].G ^= 0xffff;
                    colors[counter].B ^= 0xffff;
                }

                image.SetLookupTable16(colors);
            }
            else
            {
                RasterColor[] colors = image.GetPalette();
                if (colors == null)
                {
                    if (image.HasRegion)
                        image.MakeRegionEmpty();
                    InvertCommand invert = new InvertCommand();
                    invert.Run(image);
                }
                else
                {
                    int length = colors.Length;
                    int counter;

                    for (counter = 0; counter < length; counter++)
                    {
                        colors[counter].R ^= 0xff;
                        colors[counter].G ^= 0xff;
                        colors[counter].B ^= 0xff;
                    }

                    image.SetPalette(colors, 0, length);
                }
            }
        }
#endif //LEADTOOLS_V175_OR_LATER
        private void _printDocument_BeginPrint(object sender, PrintEventArgs e)
        {
            // This demo only prints one page at a time, so there is no need to re-start the print page number
        }

        private void _printDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            ColorResolutionCommand colorResolutionCommand = new ColorResolutionCommand(ColorResolutionCommandMode.InPlace, 24, RasterByteOrder.Bgr, RasterDitheringMethod.None, ColorResolutionCommandPaletteFlags.None, null);
            colorResolutionCommand.Run(PrintImage);

            // Get the print document object
            PrintDocument document = sender as PrintDocument;

            // Create an new LEADTOOLS image printer class
            RasterImagePrinter printer = new RasterImagePrinter();

            // Set the document object so page calculations can be performed
            printer.PrintDocument = document;

            // We want to fit and center the image into the maximum print area
            printer.SizeMode = RasterPaintSizeMode.FitAlways;
            printer.HorizontalAlignMode = RasterPaintAlignMode.Center;
            printer.VerticalAlignMode = RasterPaintAlignMode.Center;

            // Account for FAX images that may have different horizontal and vertical resolution
            printer.UseDpi = true;

            // Print the whole image
            printer.ImageRectangle = Rectangle.Empty;

            // Use maximum page dimension ignoring the margins, this will be equivalant of printing
            // using Windows Photo Gallery
            printer.PageRectangle = RectangleF.Empty;
            printer.UseMargins = false;

            // Print the current page
            printer.Print(PrintImage, PrintImage.Page, e);

            // Inform the printer we have no more pages to print
            e.HasMorePages = false;
        }

        private void _printDocument_EndPrint(object sender, PrintEventArgs e)
        {
            // Nothing to do here
        }

        public bool ApplyToAll
        {
            get { return _applyToAll; }
            set { _applyToAll = value; }
        }

        public int CellIndex
        {
            get
            {
                return _cellIndex;
            }
            set
            {
                _cellIndex = value;
            }
        }

        public int Images
        {
            get
            {
                return _images;
            }

            set
            {
                _images = value;
            }
        }

        public MedicalViewer Viewer
        {
            get
            {
                return _medicalViewer;
            }
        }

        public void RemoveSelectedCells()
        {
            int currentCellIndex = 0;
            while (currentCellIndex < Viewer.Cells.Count)
            {
                if (((MedicalViewerMultiCell)Viewer.Cells[currentCellIndex]).Selected)
                    Viewer.Cells.RemoveAt(currentCellIndex);
                else
                    ++currentCellIndex;
            }
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            if (_medicalViewer != null)
                _medicalViewer.Size = new Size(_mainPanel.ClientRectangle.Right, _mainPanel.ClientRectangle.Bottom);
        }

        private void _miEditRemoveSelectedCells_Click(object sender, EventArgs e)
        {
            RemoveSelectedCells();
        }

        private void _miEditSelectAll_Click(object sender, EventArgs e)
        {
            if (_medicalViewer != null)
                _medicalViewer.Cells.SelectAll(true);
        }

        private void _miEditDeselectAll_Click(object sender, EventArgs e)
        {
            if (_medicalViewer != null)
                _medicalViewer.Cells.SelectAll(false);
        }

        private void _miEditInvertSelection_Click(object sender, EventArgs e)
        {
            if (_medicalViewer != null)
                _medicalViewer.Cells.InvertSelection();
        }

        private DialogResult ShowViewerDialogs(Form Dialog)
        {
            return Dialog.ShowDialog(this);
        }

        int GetDicomFrameNumber(DicomDataSet ds)
        {
            int pageIndex;
            int frameNumber = -1;
            int pageCount = ds.GetImageCount(null);
            RasterImage image;

            int maxWidth = 0;

            for (pageIndex = 0; pageIndex < pageCount; pageIndex++)
            {
                image = ds.GetImage(null, pageIndex, 0, RasterByteOrder.Gray, DicomGetImageFlags.AutoApplyVoiLut | DicomGetImageFlags.AutoApplyModalityLut | DicomGetImageFlags.AllowRangeExpansion);

                if (image.Width > maxWidth)
                {
                    maxWidth = image.Width;
                    frameNumber = pageIndex;
                }
                else if (image.Width == maxWidth)
                {
                    frameNumber = -1;
                }

                image.Dispose();
            }
            return frameNumber;
        }

        // This method returns the specified DICOM tag in a string format.
        string GetDicomTag(DicomDataSet ds, long tag)
        {
            DicomElement patientElement = ds.FindFirstElement(null,
                                                 tag,
                                                 true);

            if (patientElement != null)
                return ds.GetConvertValue(patientElement);

            return null;
        }


        // Open "LEAD Open File Dialog" and return the selected image
        private RasterImage LoadImage(out string photometricInterpretation)
        {
            photometricInterpretation = "";
            ImageFileLoader loader = new ImageFileLoader();

            try
            {
                loader.ShowLoadPagesDialog = true;

                using (RasterCodecs codecs = new RasterCodecs())
                {
                    if (loader.Load(this, codecs, false) > 0)
                    {
                        RasterImage image;
                        DicomDataSet dicomDataSet = new DicomDataSet();

                        try
                        {
                            dicomDataSet.Load(loader.FileName, DicomDataSetLoadFlags.None);
                            int frameIndex = GetDicomFrameNumber(dicomDataSet);
                            image = dicomDataSet.GetImage(null, frameIndex, 0, RasterByteOrder.Gray, DicomGetImageFlags.AutoApplyVoiLut | DicomGetImageFlags.AutoApplyModalityLut | DicomGetImageFlags.AllowRangeExpansion);

                            photometricInterpretation = GetDicomTag(dicomDataSet, DicomTag.PhotometricInterpretation);

                            return image;
                        }
                        catch (Exception)
                        {
                            // if the program fails to load the image using the DicomDataSet, then try using the codecs instead
                            CounterDialog counter = new CounterDialog(this, codecs);
                            _images = 1;
                            counter.Show(this);
                            counter.Update();
                            return codecs.Load(loader.FileName, 0, CodecsLoadByteOrder.BgrOrGray, loader.FirstPage, loader.LastPage);
                        }
                        finally
                        {
                            dicomDataSet.Dispose();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Messager.ShowFileOpenError(this, loader.FileName, ex);
            }

            return null;
        }

        private RasterImage GetImage(DicomDataSet dicomDataSet, string imagePath, int index)
        {
            try
            {
                dicomDataSet.Load(imagePath, DicomDataSetLoadFlags.None);
                return dicomDataSet.GetImage(null, index, 0, RasterByteOrder.Gray, DicomGetImageFlags.AutoApplyVoiLut | DicomGetImageFlags.AutoApplyModalityLut | DicomGetImageFlags.AllowRangeExpansion);

            }
            catch (Exception)
            {
                RasterCodecs _codecs = new RasterCodecs();

                return _codecs.Load(imagePath, 0, CodecsLoadByteOrder.BgrOrGrayOrRomm, 1, 1);
            }
        }
#if LEADTOOLS_V175_OR_LATER
        // Load the DICOM file
        private SeriesInformation LoadDICOM(string imagePath)
        {
            try
            {
                SeriesInformation imageInformation = new SeriesInformation();


                DicomDataSet dicomDataSet = new DicomDataSet();

                imageInformation.Image = GetImage(dicomDataSet, imagePath, 0);
                if (imageInformation.Image == null)
                {
                    dicomDataSet.Dispose();
                    return null;
                }

                double[] orientation;
                double[] doubleArray;

                DicomElement patientElement = dicomDataSet.FindFirstElement(null,
                                                                 DicomTag.PixelSpacing,
                                                                 true);

                if (patientElement != null)
                {
                    doubleArray = dicomDataSet.GetDoubleValue(patientElement, 0, 1);
                    imageInformation.VoxelSpacing = new Point3D((float)doubleArray[0], (float)doubleArray[0], 0);
                }

                patientElement = dicomDataSet.FindFirstElement(null,
                                                     DicomTag.ImageOrientationPatient,
                                                     true);

                if (patientElement != null)
                {
                    orientation = dicomDataSet.GetDoubleValue(patientElement, 0, 6);
                    imageInformation.ImageOrientation = orientation;
                }

                patientElement = dicomDataSet.FindFirstElement(null,
                                                     DicomTag.ImagePositionPatient,
                                                     true);

                if (patientElement != null)
                {
                    doubleArray = dicomDataSet.GetDoubleValue(patientElement, 0, 3);
                    imageInformation.ImagePosition = Point3D.FromDoubleArray(doubleArray);
                }

                patientElement = dicomDataSet.FindFirstElement(null,
                                                     DicomTag.FrameOfReferenceUID,
                                                     true);

                if (patientElement != null)
                {
                    string str = dicomDataSet.GetConvertValue(patientElement);
                    imageInformation.FrameOfReferenceUID = str;
                }


                imageInformation.InstitutionName = GetDicomTag(dicomDataSet, DicomTag.InstitutionName);
                imageInformation.PatientName = GetDicomTag(dicomDataSet, DicomTag.PatientName);
                imageInformation.PatientAge = GetDicomTag(dicomDataSet, DicomTag.PatientAge);
                imageInformation.PatientBirthDate = GetDicomTag(dicomDataSet, DicomTag.PatientBirthDate);
                imageInformation.PatientSex = GetDicomTag(dicomDataSet, DicomTag.PatientSex);
                imageInformation.PatientID = GetDicomTag(dicomDataSet, DicomTag.PatientID);
                imageInformation.AccessionNumber = GetDicomTag(dicomDataSet, DicomTag.AccessionNumber);
                imageInformation.StudyDate = GetDicomTag(dicomDataSet, DicomTag.StudyDate);
                imageInformation.AcquisitionTime = GetDicomTag(dicomDataSet, DicomTag.AcquisitionTime);
                imageInformation.SeriesTime = GetDicomTag(dicomDataSet, DicomTag.SeriesTime);
                imageInformation.StationName = GetDicomTag(dicomDataSet, DicomTag.StationName);
                imageInformation.StudyID = GetDicomTag(dicomDataSet, DicomTag.StudyID);
                imageInformation.SeriesDescription = GetDicomTag(dicomDataSet, DicomTag.SeriesDescription);
                imageInformation.ImageComments = GetDicomTag(dicomDataSet, DicomTag.ImageComments);

                return imageInformation;
            }
            catch (System.Exception ex)
            {
                Messager.Show(this, ex, MessageBoxIcon.Exclamation);
            }

            return null;
        }
#endif //LEADTOOLS_V175_OR_LATER

        private void GetFileName(out string fileName)
        {
            RasterCodecs codecs = new RasterCodecs();
            ImageFileLoader loader = new ImageFileLoader();
            fileName = "";

            try
            {
                loader.ShowLoadPagesDialog = false;
                if (loader.Load(this, codecs, false) != 0)
                {
                    fileName = "";
                    if (loader.LastPage != 0)
                    {
                        fileName = loader.FileName;

                        if (fileName.IndexOf("DICOMDIR") != -1)
                        {
                            MessageBox.Show("You cannot load the DICOMDIR from here, use Load DICOMDIR instead", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            fileName = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Messager.ShowFileOpenError(this, loader.FileName, ex);
            }
        }
#if LEADTOOLS_V175_OR_LATER

        public RasterImage LoadFusionDicom(out string seriesName)
        {
            seriesName = "";
            string imagePath;
            GetFileName(out imagePath);

            if (imagePath != "")
            {
                SeriesInformation imageInformation = LoadDICOM(imagePath);

                seriesName = imageInformation.PatientName;

                if (seriesName == null)
                {
                    string[] stringArray = imagePath.Split(new char[1] { '\\' });

                    seriesName = stringArray[stringArray.Length - 1];
                }


                return imageInformation.Image;
            }

            return null;
        }

#endif //LEADTOOLS_V175_OR_LATER




        private void _fileMenuItem_insertCell_Click(object sender, EventArgs e)
        {
            try
            {
                if (ShowViewerDialogs(new InsertCellDialog(this)) == DialogResult.OK)
                {
                    MedicalViewer medicalViewer = this.Viewer;
                    String photometricInterpretation;
                    RasterImage image = LoadImage(out photometricInterpretation);

                    // Insert new cell if the user has selected an image.
                    if (image != null)
                    {
                        MedicalViewerMultiCell cell = new MedicalViewerMultiCell(image, true, 1, 1);
                        cell.PhotometricInterpretation = photometricInterpretation;
                        int index;
                        if (CellIndex != -1)
                        {
                            index = CellIndex;
                            medicalViewer.Cells.Insert(index, cell);
                        }
                        else
                        {
                            index = medicalViewer.Cells.Count;
                            medicalViewer.Cells.Add(cell);
                        }
                        cell.Image = image;
                        _fusionListNames.Add(new List<String>[image.PageCount]);


                        InitializeCell(cell);
                        InitializeEvents(cell);
                        CopyPropertiesFromGlobalCell(cell);

                        cell.SetTag(0, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.UserData, "Overlay Text 1");
                        cell.SetTag(1, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.UserData, "Overlay Text 2");
                        cell.SetTag(2, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.UserData, "Overlay Text 3");
                        cell.SetTag(3, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.UserData, "Overlay Text 4");
                        cell.SetTag(4, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.UserData, "Overlay Text 5");
                        cell.SetTag(5, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.UserData, "Overlay Text 6");
                        cell.SetTag(6, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.UserData, "Overlay Text 7");
                        cell.SetTag(1, MedicalViewerTagAlignment.LeftCenter, MedicalViewerTagType.UserData, "Overlay Text 8");
                        cell.SetTag(1, MedicalViewerTagAlignment.BottomLeft, MedicalViewerTagType.UserData, "Overlay Text 9");
                        cell.SetTag(0, MedicalViewerTagAlignment.TopCenter, MedicalViewerTagType.UserData, "Overlay Text 10");
                        cell.SetTag(0, MedicalViewerTagAlignment.BottomCenter, MedicalViewerTagType.UserData, "Overlay Text 12");
                        cell.SetTag(0, MedicalViewerTagAlignment.TopRight, MedicalViewerTagType.UserData, "Overlay Text 11");
                        cell.SetTag(0, MedicalViewerTagAlignment.RightCenter, MedicalViewerTagType.UserData, "R");
                        cell.SetTag(0, MedicalViewerTagAlignment.BottomLeft, MedicalViewerTagType.RulerUnit);
                        cell.SetTag(7, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.Scale);
                        cell.SetTag(8, MedicalViewerTagAlignment.TopLeft, MedicalViewerTagType.Frame);
                        if (image.GrayscaleMode != RasterGrayscaleMode.None)
                            cell.SetTag(2, MedicalViewerTagAlignment.BottomLeft, MedicalViewerTagType.WindowLevelData);

                        ApplyToCell(cell);
                    }
                }
            }
            catch (Exception ex)
            {
                Messager.ShowError(this, ex);
            }
        }

        private void _fileMenuItem_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void _miEditFreezeCell_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new FreezeCellDialog(this));
        }

        private void _miEditToggleFreeze_Click(object sender, EventArgs e)
        {
            if (_medicalViewer != null)
            {
                foreach (MedicalViewerCell cell in _medicalViewer.Cells)
                {
                    if (cell.Selected)
                        cell.Frozen = !cell.Frozen;
                }
            }
        }

        private void _miPropertiesViewerProperties_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new ViewerPropertiesDialog(this));
        }

        private void _miPropertiesCellProperties_Click(object sender, EventArgs e)
        {
            bool selected = false;
            int i = 0;
            while (!selected && i < this.Viewer.Cells.Count)
            {
                if (((MedicalViewerMultiCell)this.Viewer.Cells[i]).Selected)
                    selected = true;
                else
                    ++i;
            }
            ShowViewerDialogs(new CellPropertiesDialog(this, i));
        }

        private void _miActionWindowLevelSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.WindowLevel));
        }

        private void _miActionAlphaSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.Alpha));
        }

        private void _miActionScaleSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.Scale));
        }

        private void _miMagnifySet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.MagnifyGlass));
        }

        private void _miActionStackSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.Stack));
        }

        private void _miActionOffsetSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.Offset));
        }

        private void setToolStripMenuItem6_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.RectangleRegion));
        }

        private void _miRegionEllipseSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.EllipseRegion));
        }

        private void _miRegionSquareSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.SquareRegion));
        }

        private void _miRegionCircleSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.CircleRegion));
        }

        private void _miRegionPolygonSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.PolygonRegion));
        }

        private void _miRegionFreeHandSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.FreeHandRegion));
        }

        private void _miRegionMagicWandSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.MagicWandRegion));
        }

        private void _miRegionColorRangeSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.ColorRangeRegion));
        }

        private void _miAnnotationRectangleSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.AnnotationRectangle));
        }

        private void _miAnnotationEllipseSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.AnnotationEllipse));
        }

        private void _miAnnotationArrowSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.AnnotationArrow));
        }

        private void _miAnnotationTextSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.AnnotationText));
        }

        private void _miAnnotationAngleSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.AnnotationAngle));
        }

        private void _miAnnotationHiliteSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.AnnotationHilite));
        }

        private void _miActionWindowLevelCustomize_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new WindowLevelPropertiesDialog(this, GetSelectedCell()));
        }

        // This method add a key list to the specifid combo box
        public void AddKeysToCombo(ComboBox keyComboBox, Keys currentKey)
        {
            #region Added keys
            Keys[] keys =
         {
            Keys.None,
            Keys.Space,
            Keys.PageUp,
            Keys.PageDown,
            Keys.End,
            Keys.Home,
            Keys.Left,
            Keys.Up,
            Keys.Right,
            Keys.Down,
            Keys.PrintScreen,
            Keys.Insert,
            Keys.Delete,
            Keys.D0,
            Keys.D1,
            Keys.D2,
            Keys.D3,
            Keys.D4,
            Keys.D5,
            Keys.D6,
            Keys.D7,
            Keys.D8,
            Keys.D9,
            Keys.A,
            Keys.B,
            Keys.C,
            Keys.D,
            Keys.E,
            Keys.F,
            Keys.G,
            Keys.H,
            Keys.I,
            Keys.J,
            Keys.K,
            Keys.L,
            Keys.M,
            Keys.N,
            Keys.O,
            Keys.P,
            Keys.Q,
            Keys.R,
            Keys.S,
            Keys.T,
            Keys.U,
            Keys.V,
            Keys.W,
            Keys.X,
            Keys.Y,
            Keys.Z,
            Keys.NumPad0,
            Keys.NumPad1,
            Keys.NumPad2,
            Keys.NumPad3,
            Keys.NumPad4,
            Keys.NumPad5,
            Keys.NumPad6,
            Keys.NumPad7,
            Keys.NumPad8,
            Keys.NumPad9,
            Keys.Multiply,
            Keys.Add,
            Keys.Subtract,
            Keys.Decimal,
            Keys.F1,
            Keys.F2,
            Keys.F3,
            Keys.F4,
            Keys.F5,
            Keys.F6,
            Keys.F7,
            Keys.F8,
            Keys.F9,
            Keys.F10,
            Keys.F11,
            Keys.F12
         };

            foreach (Keys key in keys)
                keyComboBox.Items.Add(key);

            keyComboBox.SelectedIndex = keyComboBox.Items.IndexOf(currentKey);
            #endregion
        }

        public void AddModifiersToCombo(ComboBox keyComboBox, MedicalViewerModifiers currentKey)
        {
            #region Added modifiers
            MedicalViewerModifiers[] modifiers =
         {
            MedicalViewerModifiers.None,
            MedicalViewerModifiers.Ctrl,
            MedicalViewerModifiers.Alt
         };

            foreach (MedicalViewerModifiers modifier in modifiers)
                keyComboBox.Items.Add(modifier);

            keyComboBox.SelectedIndex = keyComboBox.Items.IndexOf(currentKey);
            #endregion
        }

        public int GetIndex(ComboBox combo, NumericTextBox text)
        {
            if (combo.Text == "None")
                return -3;
            else if (combo.Text == "Selected")
                return -2;
            else if (combo.Text == "All")
                return -1;
            else
                return text.Value;
        }

        public bool IsThereASelectedCell()
        {
            int index = 0;
            while (index < Viewer.Cells.Count)
            {
                if (((MedicalViewerMultiCell)Viewer.Cells[index]).Selected)
                    return true;
                else
                    index++;
            }
            return false;
        }

        private MedicalViewerCell GetSelectedCell()
        {
            if (_medicalViewer != null)
            {
                foreach (MedicalViewerCell cell in _medicalViewer.Cells)
                {
                    if (cell.Selected)
                        return cell;
                }
            }
            return null;
        }

        public int SearchForFirstSelected()
        {
            int index = 0;
            bool found = false;

            while (!found && index < Viewer.Cells.Count)
            {
                if (((MedicalViewerMultiCell)Viewer.Cells[index]).Selected)
                    found = true;
                else
                    index++;
            }
            return found ? index : ((Viewer.Cells.Count != 0) ? 0 : -1);
        }

        private void _miActionScaleCustomizeScale_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new ScalePropertiesDialog(this, GetSelectedCell()));
        }

        private void _miActionMagnifyCustomizeMagnify_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new MagnifyGlassProperties(this, GetSelectedCell()));
        }

        private void _miActionStackCustomizeStack_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new StackPropertiesDialog(this, GetSelectedCell()));
        }

        private void _miActionOffsetCustomizeOffset_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new OffsetPropertiesDialog(this, GetSelectedCell()));
        }

        private void _miAnnotationTextCustomizeText_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new TextAnnotationDialog(this));
        }

        private void _miAnnotationRectangleCustomizeRectangle_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new RectangleAnnotationDialog(this));
        }

        private void _miAnnotationEllipseCustomizeEllipse_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new EllipseAnnotationDialog(this));
        }

        private void _miActionArrowCustomizeArrow_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new ArrowAnnotationDialog(this));
        }

        private void _miAnnotationAngleCustomizeAngle_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new AngleAnnotationDialog(this));
        }

        private void _miAnnotationHiliteCustomizeHilite_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new HiliteAnnotationDialog(this));
        }

        private void _miStatisticsStatistics_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new StatisticsDialog(this));
        }

        private void _miAnnotationRulerSet_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.AnnotationRuler));
        }

        private void _miAnnotationRulerCustomize_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new RulerAnnotationDialog(this));
        }

        private void _miEditAnimation_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new AnimationDialog(this, SearchForFirstSelected()));
        }

        public static void ShowColorDialog(Label label)
        {
            ColorDialog colorDlg = new ColorDialog();

            colorDlg.Color = label.BackColor;
            if (colorDlg.ShowDialog() == DialogResult.OK)
            {
                label.BackColor = colorDlg.Color;
            }
        }

        private void ApplyFilter(RasterCommand command)
        {
            // This will apply the command to all selected cells.
            foreach (MedicalViewerCell cell in Viewer.Cells)
            {
                if (cell.Selected)
                {
                    // Check whether to apply the command to all the image pages or only of the active page
                    if (_miEffectOptionsApplyToAllSubCells.Checked)
                    {
                        // Apply the command to all the image pages
                        int index;
                        for (index = 1; index <= cell.Image.PageCount; index++)
                        {
                            cell.Image.Page = index;
                            command.Run(cell.Image);
                        }
                    }
                    else
                    {
                        // Apply the command to only the active page.
                        MedicalViewerStack stack = (MedicalViewerStack)cell.GetActionProperties(MedicalViewerActionType.Stack, Viewer.Cells.IndexOf(cell));
                        cell.Image.Page = stack.ScrollValue + stack.ActiveSubCell + 1;
                        command.Run(cell.Image);
                    }
                    // Redraw the cell to adopt the new changes.
                    cell.Invalidate();
                }
            }
        }

        private void _editMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            bool selected = IsThereASelectedCell();
            bool enabled = Viewer.Cells.Count != 0;
            _miEditCalibrateRuler.Enabled = enabled;
            _miEditConvertAnnotationToRegion.Enabled = enabled;
            _miEditAnimation.Enabled = enabled;
            _miEditFreezeCell.Enabled = enabled;
            _miEditToggleFreeze.Enabled = enabled && selected;
            _miEditSelectAll.Enabled = enabled;
            _miEditDeselectAll.Enabled = enabled && selected;
            _miEditInvertSelection.Enabled = enabled;
            _miEditRepositionCell.Enabled = (Viewer.Cells.Count > 1);
            _miEditRemoveCell.Enabled = enabled;
            _miEditRemoveSelectedCells.Enabled = enabled;

            if (enabled)
            {
                int index = 0;
                bool rulerFound = false;
                bool selectedAnnotationFound = false;
                MedicalViewerAnnotationAttributes annotationAttributes;

                MedicalViewerMultiCell cell;
                // search if there is at least one selected ruler, or one selected closed shape annotation object (Rectangle, Ellipse or Hilite).
                for (index = 0; index < Viewer.Cells.Count; ++index)
                {
                    cell = ((MedicalViewerMultiCell)Viewer.Cells[index]);
                    // Get the selected annotation object of the cell.
                    annotationAttributes = cell.GetSelectedAnnotationAttributes(-2);

                    // Check the type of the selected annotation object.
                    if (annotationAttributes.Type != MedicalViewerActionType.None)
                    {
                        switch (annotationAttributes.Type)
                        {
                            case MedicalViewerActionType.AnnotationRectangle:
                            case MedicalViewerActionType.AnnotationEllipse:
                            case MedicalViewerActionType.AnnotationHilite:
                                if (Math.Abs(cell.SubCells[cell.ActiveSubCell].SelectedObject.CalculateRotateAngle()) < 0.1)
                                    selectedAnnotationFound = true;
                                break;
                            case MedicalViewerActionType.AnnotationRuler:
                                rulerFound = true;
                                break;
                        }
                    }
                    // If both (ruler) & closed shape annotation object are found, then there is no need for more searching.
                    if (selectedAnnotationFound && rulerFound)
                        break;
                }

                _miEditCalibrateRuler.Enabled = rulerFound;
                _miEditConvertAnnotationToRegion.Enabled = selectedAnnotationFound;
            }
        }

        private void _miEffectOptionsApplyToAllSubCells_Click(object sender, EventArgs e)
        {
            _miEffectOptionsApplyToAllSubCells.Checked = !_miEffectOptionsApplyToAllSubCells.Checked;
        }

        private void _miEffectInvert_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V16_OR_LATER
            int cellIndex;
            MedicalViewerMultiCell cell = null;
            for (cellIndex = 0; cellIndex < Viewer.Cells.Count; cellIndex++)
            {
                cell = ((MedicalViewerMultiCell)Viewer.Cells[cellIndex]);
                if (cell.Selected)
                {
                    // Check whether to apply the Invert to all the image pages or only on the active page
                    if (_miEffectOptionsApplyToAllSubCells.Checked)
                    {
                        // Apply the command to all the image pages
                        ((MedicalViewerMultiCell)Viewer.Cells[cellIndex]).InvertImage();
                    }
                    else
                    {
                        // Apply the command to only the active page.
                        MedicalViewerStack stack = (MedicalViewerStack)cell.GetActionProperties(MedicalViewerActionType.Stack, cellIndex);
                        ((MedicalViewerMultiCell)Viewer.Cells[cellIndex]).InvertImage(stack.ScrollValue + stack.ActiveSubCell);
                    }
                }
            }
#endif
        }

        private void _miEffectReverse_Click(object sender, EventArgs e)
        {
            ApplyFilter(new FlipCommand(true));
        }

        private void _miEffectFlip_Click(object sender, EventArgs e)
        {
            ApplyFilter(new FlipCommand(false));
        }

        private void _miHelpAbout_Click(object sender, EventArgs e)
        {
         new AboutDialog("Medical Viewer").ShowDialog(this);
        }

        private void _propertiesMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            bool enabled = Viewer.Cells.Count != 0;
            _miPropertiesCellProperties.Enabled = enabled;
        }

        void _fileMenuItem_DropDownOpening(object sender, System.EventArgs e)
        {
            bool enabled = (Viewer.Cells.Count != 0) && IsThereASelectedCell();
            _printCellMenuItem.Enabled = enabled;
        }

        void loadAnnotationsToolStripMenuItem_DropDownOpening(object sender, System.EventArgs e)
        {
            bool enabled = (Viewer.Cells.Count != 0) && IsThereASelectedCell();
            selectedCellsToolStripMenuItem1.Enabled = enabled;
            allCellToolStripMenuItem.Enabled = (Viewer.Cells.Count != 0);
        }

        void saveAnnotationsToolStripMenuItem_DropDownOpening(object sender, System.EventArgs e)
        {
            bool enabled = (Viewer.Cells.Count != 0) && IsThereASelectedCell();
            selectedCellsToolStripMenuItem.Enabled = enabled;
            allCellsToolStripMenuItem.Enabled = (Viewer.Cells.Count != 0);
        }

        void saveRegionsToolStripMenuItem_DropDownOpening(object sender, System.EventArgs e)
        {
            bool enabled = (Viewer.Cells.Count != 0) && IsThereASelectedCell();
            selectedCellsToolStripMenuItem2.Enabled = enabled;
            allCellsToolStripMenuItem1.Enabled = (Viewer.Cells.Count != 0);
        }

        void loadRegionsToolStripMenuItem_DropDownOpening(object sender, System.EventArgs e)
        {
            bool enabled = (Viewer.Cells.Count != 0) && IsThereASelectedCell();
            selectedCellsToolStripMenuItem3.Enabled = enabled;
            allCellsToolStripMenuItem2.Enabled = (Viewer.Cells.Count != 0);
        }



        private void _effectMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            bool enabled = (Viewer.Cells.Count != 0) && IsThereASelectedCell();

            _miEffectFlip.Enabled = enabled;
            _miEffectInvert.Enabled = enabled;
            _miEffectReverse.Enabled = enabled;
        }

        private void _miActionAlphaCustomizeAlpha_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new AlphaPropertiesDialog(this, GetSelectedCell()));
        }

        private void _miEditRemoveCell_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new RemoveCellDialog(this));
        }

        private void _miEditCalibrateRuler_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new CalibrateRulerDialog(this));
        }

        private void _miEditConvertAnnotationToRegion_Click(object sender, EventArgs e)
        {
            foreach (MedicalViewerCell cell in Viewer.Cells)
            {
                if (cell.Selected)
                    cell.ConvertAnnotationToRegion(RasterRegionCombineMode.Or, true);
            }
        }

        private void _miEditRepositionCell_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new RepositionCellDialog(this));
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DicomEngine.Shutdown();
        }

        private void _printCellMenuItem_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V16_OR_LATER
            ShowViewerDialogs(new PrintCellDialog(this));
#endif
        }

        private void setToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.NudgeTool));
        }

        private void customizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V16_OR_LATER
            ShowViewerDialogs(new NudgeToolDialog(this, MedicalViewerActionType.NudgeTool));
#endif
        }

        private void setToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.ShrinkTool));
        }

        private void customizeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V16_OR_LATER
            ShowViewerDialogs(new NudgeToolDialog(this, MedicalViewerActionType.ShrinkTool));
#endif
        }

        private void selectedCellsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // saving annotations
            string fileName = ShowSaveDialog(false);
            int index = 0;

            if (fileName != null)
            {
                foreach (MedicalViewerMultiCell cell in Viewer.Cells)
                {
                    if (cell.Selected)
                    {
                        if (index == 0)
                            cell.SaveAnnotations(fileName, -1, 1, MedicalViewerFileOperation.Create);
                        else
                            cell.SaveAnnotations(fileName, -1, 1, MedicalViewerFileOperation.Append);
                        index++;
                    }
                }
            }
        }

        private string ShowSaveDialog(bool forRegion)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.AddExtension = true;
            if (forRegion)
            {
                saveDialog.Filter = "Region Files (*.rgn)|*.rgn";
            }
            else
            {
                saveDialog.Filter = "Annotation Files (*.ann)|*.ann";
            }
            DialogResult result = saveDialog.ShowDialog();
            if (result == DialogResult.OK)
                return saveDialog.FileName;
            else
                return null;
        }

        private string ShowLoadDialog(bool forRegion)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            if (forRegion)
            {
                openDialog.Filter = "Region Files (*.rgn)|*.rgn";
            }
            else
            {
                openDialog.Filter = "Annotation Files (*.ann)|*.ann";
            }

            DialogResult result = openDialog.ShowDialog();
            if (result == DialogResult.OK)
                return openDialog.FileName;
            else
                return null;
        }

        private void allCellsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string fileName = ShowSaveDialog(false);
            int index = 0;

            if (fileName != null)
            {
                foreach (MedicalViewerMultiCell cell in Viewer.Cells)
                {
                    if (index == 0)
                        cell.SaveAnnotations(fileName, -1, 1, MedicalViewerFileOperation.Create);
                    else
                        cell.SaveAnnotations(fileName, -1, 1, MedicalViewerFileOperation.Append);
                    index++;
                }
            }
        }

        private void selectedCellsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string fileName = ShowLoadDialog(false);
            int count = 1;

            if (fileName != null)
            {
                foreach (MedicalViewerMultiCell cell in Viewer.Cells)
                {
                    if (cell.Selected)
                    {
                        cell.LoadAnnotations(fileName, -1, count);
                        count += cell.Image.PageCount;
                    }
                }
            }
        }

        private void allCellToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string fileName = ShowLoadDialog(false);
            int count = 1;

            if (fileName != null)
            {
                foreach (MedicalViewerMultiCell cell in Viewer.Cells)
                {
                    cell.LoadAnnotations(fileName, -1, count);
                    count += cell.Image.PageCount;
                }
            }
        }

        private void selectedCellsToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            string fileName = ShowSaveDialog(true);
            int index = 0;

            if (fileName != null)
            {
                foreach (MedicalViewerMultiCell cell in Viewer.Cells)
                {
                    if (cell.Selected)
                    {
                        if (index == 0)
                            cell.SaveRegion(fileName, -1, 1, MedicalViewerFileOperation.Create);
                        else
                            cell.SaveRegion(fileName, -1, 1, MedicalViewerFileOperation.Append);
                        index++;
                    }
                }
            }
        }

        private void allCellsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string fileName = ShowSaveDialog(true);
            int index = 0;

            if (fileName != null)
            {
                foreach (MedicalViewerMultiCell cell in Viewer.Cells)
                {
                    if (index == 0)
                        cell.SaveRegion(fileName, -1, 1, MedicalViewerFileOperation.Create);
                    else
                        cell.SaveRegion(fileName, -1, 1, MedicalViewerFileOperation.Append);
                    index++;
                }
            }
        }

        private void selectedCellsToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            string fileName = ShowLoadDialog(true);
            int count = 1;

            if (fileName != null)
            {
                foreach (MedicalViewerMultiCell cell in Viewer.Cells)
                {
                    if (cell.Selected)
                    {
                        cell.LoadRegion(fileName, -1, count);
                        count += cell.Image.PageCount;
                    }
                }
            }
        }

        private void allCellsToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            string fileName = ShowLoadDialog(true);
            int count = 1;

            if (fileName != null)
            {
                foreach (MedicalViewerMultiCell cell in Viewer.Cells)
                {
                    cell.LoadRegion(fileName, -1, count);
                    count += cell.Image.PageCount;
                }
            }
        }

        public void ApplyToCell(MedicalViewerCell cell)
        {
            int index;
            MedicalViewerIcon icon;
            MedicalViewerIcon cellIcon;
            MedicalViewerCell defaultCell = DefaultCell;


            for (index = 0; index < cell.Titlebar.Icons.Length; index++)
            {
                icon = cell.Titlebar.Icons[index];
                cellIcon = defaultCell.Titlebar.Icons[index];

                if (icon.Visible != cellIcon.Visible)
                    icon.Visible = cellIcon.Visible;

                if (icon.Color != cellIcon.Color)
                    icon.Color = cellIcon.Color;

                if (icon.ColorPressed != cellIcon.ColorPressed)
                    icon.ColorPressed = cellIcon.ColorPressed;

                if (icon.ColorHover != cellIcon.ColorHover)
                    icon.ColorHover = cellIcon.ColorHover;

                if (icon.ReadOnly != cellIcon.ReadOnly)
                    icon.ReadOnly = cellIcon.ReadOnly;
            }

            if (cell.CellBackColor != defaultCell.CellBackColor)
                cell.CellBackColor = defaultCell.CellBackColor;

            if (cell.TextColor != defaultCell.TextColor)
                cell.TextColor = defaultCell.TextColor;

            if (cell.TextShadowColor != defaultCell.TextShadowColor)
                cell.TextShadowColor = defaultCell.TextShadowColor;

            if (cell.ActiveBorderColor != defaultCell.ActiveBorderColor)
                cell.ActiveBorderColor = defaultCell.ActiveBorderColor;

            if (cell.NonActiveBorderColor != defaultCell.NonActiveBorderColor)
                cell.NonActiveBorderColor = defaultCell.NonActiveBorderColor;

            if (cell.ActiveSubCellBorderColor != defaultCell.ActiveSubCellBorderColor)
                cell.ActiveSubCellBorderColor = defaultCell.ActiveSubCellBorderColor;

            if (cell.RulerInColor != defaultCell.RulerInColor)
                cell.RulerInColor = defaultCell.RulerInColor;

            if (cell.RulerOutColor != defaultCell.RulerOutColor)
                cell.RulerOutColor = defaultCell.RulerOutColor;

            if (cell.Titlebar.UseCustomColor != defaultCell.Titlebar.UseCustomColor)
                cell.Titlebar.UseCustomColor = defaultCell.Titlebar.UseCustomColor;

            if (cell.Titlebar.Color != defaultCell.Titlebar.Color)
                cell.Titlebar.Color = defaultCell.Titlebar.Color;

            if (cell.Titlebar.Visible != defaultCell.Titlebar.Visible)
                cell.Titlebar.Visible = defaultCell.Titlebar.Visible;

            if (cell.TextQuality != defaultCell.TextQuality)
                cell.TextQuality = defaultCell.TextQuality;

            if (cell.RulerStyle != defaultCell.RulerStyle)
                cell.RulerStyle = defaultCell.RulerStyle;

            if (cell.ShowCellScroll != defaultCell.ShowCellScroll)
                cell.ShowCellScroll = defaultCell.ShowCellScroll;

            if (cell.ShowFreezeText != defaultCell.ShowFreezeText)
                cell.ShowFreezeText = defaultCell.ShowFreezeText;

            if (cell.PaintingMethod != defaultCell.PaintingMethod)
                cell.PaintingMethod = defaultCell.PaintingMethod;

            if (cell.MeasurementUnit != defaultCell.MeasurementUnit)
                cell.MeasurementUnit = defaultCell.MeasurementUnit;

            if (cell.BorderStyle != defaultCell.BorderStyle)
                cell.BorderStyle = defaultCell.BorderStyle;


            if (!defaultCell.Cursor.Equals(defaultCell.Cursor))
            {
                cell.Cursor = defaultCell.Cursor;
            }

            if (!defaultCell.AnnotationSelectCursor.Equals(cell.AnnotationSelectCursor))
            {
                cell.AnnotationSelectCursor = defaultCell.AnnotationSelectCursor;
            }

            if (!defaultCell.RegionDefaultCursor.Equals(cell.RegionDefaultCursor))
            {
                cell.RegionDefaultCursor = defaultCell.RegionDefaultCursor;
            }

            if (!defaultCell.AnnotationDefaultCursor.Equals(cell.AnnotationDefaultCursor))
            {
                cell.AnnotationDefaultCursor = defaultCell.AnnotationDefaultCursor;
            }

            if (!defaultCell.AnnotationMoveCursor.Equals(cell.AnnotationMoveCursor))
            {
                cell.AnnotationMoveCursor = defaultCell.AnnotationMoveCursor;
            }
        }

        public static MedicalViewerMultiCell DefaultCell
        {
            get
            {
                if (_defaultCell == null)
                {
                    _defaultCell = new MedicalViewerMultiCell(null, false, 1, 1);
                    InitializeCell(_defaultCell);
                }

                return _defaultCell;
            }
        }

        private static void CopyPropertiesFromGlobalCell(MedicalViewerCell cell)
        {
            MedicalViewerActionType actionType;
            MedicalViewerMouseButtons button;
            MedicalViewerActionFlags flags;
            MedicalViewerKeys keys;
            MedicalViewerActionType myEnum = MedicalViewerActionType.SpatialLocator;
#if LEADTOOLS_V175_OR_LATER
            myEnum = MedicalViewerActionType.SpyGlass;
#endif //LEADTOOLS_V175_OR_LATER

            for (actionType = MedicalViewerActionType.WindowLevel; actionType <= myEnum; actionType++)
            {
                if (!cell.CanExecuteAction(actionType))
                    continue;
                button = DefaultCell.GetActionButton(actionType);
                flags = DefaultCell.GetActionFlags(actionType);

                if (button != MedicalViewerMouseButtons.None)
                {
                    cell.SetAction(actionType, button, flags);
                }

                keys = DefaultCell.GetActionKeys(actionType);
                cell.SetActionKeys(actionType, keys);

                if (actionType > MedicalViewerActionType.Alpha)
                {
                    MedicalViewerBaseAction baseAction = DefaultCell.GetActionProperties(actionType);
                    cell.SetActionProperties(actionType, baseAction);
                }
            }

            MedicalViewerWindowLevel windowLevelAction = (MedicalViewerWindowLevel)DefaultCell.GetActionProperties(MedicalViewerActionType.WindowLevel);

            MedicalViewerWindowLevel windowLevel = new MedicalViewerWindowLevel();
            windowLevel.ActionCursor = windowLevelAction.ActionCursor;
            windowLevel.CircularMouseMove = windowLevelAction.CircularMouseMove;
            windowLevel.Sensitivity = windowLevelAction.Sensitivity;

            cell.SetActionProperties(MedicalViewerActionType.WindowLevel, windowLevel);


            MedicalViewerAlpha AlphaAction = (MedicalViewerAlpha)DefaultCell.GetActionProperties(MedicalViewerActionType.Alpha);

            MedicalViewerAlpha Alpha = new MedicalViewerAlpha();
            Alpha.ActionCursor = AlphaAction.ActionCursor;
            Alpha.CircularMouseMove = AlphaAction.CircularMouseMove;
            Alpha.Sensitivity = AlphaAction.Sensitivity;

            cell.SetActionProperties(MedicalViewerActionType.Alpha, Alpha);

            MedicalViewerScale ScaleAction = (MedicalViewerScale)DefaultCell.GetActionProperties(MedicalViewerActionType.Scale);

            MedicalViewerScale Scale = new MedicalViewerScale();
            Scale.ActionCursor = ScaleAction.ActionCursor;
            Scale.CircularMouseMove = ScaleAction.CircularMouseMove;
            Scale.Sensitivity = ScaleAction.Sensitivity;

            cell.SetActionProperties(MedicalViewerActionType.Scale, Scale);


            MedicalViewerStack StackAction = (MedicalViewerStack)DefaultCell.GetActionProperties(MedicalViewerActionType.Stack);

            MedicalViewerStack Stack = new MedicalViewerStack();
            Stack.ActionCursor = StackAction.ActionCursor;
            Stack.CircularMouseMove = StackAction.CircularMouseMove;
            Stack.Sensitivity = StackAction.Sensitivity;

            cell.SetActionProperties(MedicalViewerActionType.Stack, Stack);

            MedicalViewerOffset offsetAction = (MedicalViewerOffset)DefaultCell.GetActionProperties(MedicalViewerActionType.Offset);

            MedicalViewerOffset offset = new MedicalViewerOffset();
            offset.ActionCursor = offsetAction.ActionCursor;
            offset.CircularMouseMove = offsetAction.CircularMouseMove;
            offset.Sensitivity = offsetAction.Sensitivity;

            cell.SetActionProperties(MedicalViewerActionType.Offset, offset);

            MedicalViewerMagnifyGlass magnifyAction = (MedicalViewerMagnifyGlass)DefaultCell.GetActionProperties(MedicalViewerActionType.MagnifyGlass);
            cell.SetActionProperties(MedicalViewerActionType.MagnifyGlass, magnifyAction);

            int index = 0;
            MedicalViewerIcon icon;
            MedicalViewerIcon virtualCellIcon;

            for (index = 0; index < cell.Titlebar.Icons.Length; index++)
            {
                icon = cell.Titlebar.Icons[index];
                virtualCellIcon = cell.Titlebar.Icons[index];

                if (icon.Visible != virtualCellIcon.Visible)
                    icon.Visible = virtualCellIcon.Visible;

                if (icon.Color != virtualCellIcon.Color)
                    icon.Color = virtualCellIcon.Color;

                if (icon.ColorPressed != virtualCellIcon.ColorPressed)
                    icon.ColorPressed = virtualCellIcon.ColorPressed;

                if (icon.ColorHover != virtualCellIcon.ColorHover)
                    icon.ColorHover = virtualCellIcon.ColorHover;

                if (icon.ReadOnly != virtualCellIcon.ReadOnly)
                    icon.ReadOnly = virtualCellIcon.ReadOnly;
            }
            if (cell.CellBackColor != DefaultCell.CellBackColor)
                cell.CellBackColor = DefaultCell.CellBackColor;

            if (cell.TextColor != DefaultCell.TextColor)
                cell.TextColor = DefaultCell.TextColor;

            if (cell.TextShadowColor != DefaultCell.TextShadowColor)
                cell.TextShadowColor = DefaultCell.TextShadowColor;

            if (cell.ActiveBorderColor != DefaultCell.ActiveBorderColor)
                cell.ActiveBorderColor = DefaultCell.ActiveBorderColor;

            if (cell.NonActiveBorderColor != DefaultCell.NonActiveBorderColor)
                cell.NonActiveBorderColor = DefaultCell.NonActiveBorderColor;

            if (cell.ActiveSubCellBorderColor != DefaultCell.ActiveSubCellBorderColor)
                cell.ActiveSubCellBorderColor = DefaultCell.ActiveSubCellBorderColor;

            if (cell.RulerInColor != DefaultCell.RulerInColor)
                cell.RulerInColor = DefaultCell.RulerInColor;

            if (cell.RulerOutColor != DefaultCell.RulerOutColor)
                cell.RulerOutColor = DefaultCell.RulerOutColor;

            if (cell.Titlebar.UseCustomColor != DefaultCell.Titlebar.UseCustomColor)
                cell.Titlebar.UseCustomColor = DefaultCell.Titlebar.UseCustomColor;

            if (cell.Titlebar.Color != DefaultCell.Titlebar.Color)
                cell.Titlebar.Color = DefaultCell.Titlebar.Color;

            if (cell.Titlebar.Visible != DefaultCell.Titlebar.Visible)
                cell.Titlebar.Visible = DefaultCell.Titlebar.Visible;

            if (cell.TextQuality != DefaultCell.TextQuality)
                cell.TextQuality = DefaultCell.TextQuality;

            if (cell.RulerStyle != DefaultCell.RulerStyle)
                cell.RulerStyle = DefaultCell.RulerStyle;

            if (cell.ShowCellScroll != DefaultCell.ShowCellScroll)
                cell.ShowCellScroll = DefaultCell.ShowCellScroll;

            if (cell.ShowFreezeText != DefaultCell.ShowFreezeText)
                cell.ShowFreezeText = DefaultCell.ShowFreezeText;

            if (cell.PaintingMethod != DefaultCell.PaintingMethod)
                cell.PaintingMethod = DefaultCell.PaintingMethod;

            if (cell.MeasurementUnit != DefaultCell.MeasurementUnit)
                cell.MeasurementUnit = DefaultCell.MeasurementUnit;

            if (cell.BorderStyle != DefaultCell.BorderStyle)
                cell.BorderStyle = DefaultCell.BorderStyle;
        }

        public static void ApplyToCells(MedicalViewer viewer, ComboBox cmbApplyToCell, NumericTextBox txtCellIndex, ComboBox cmbApplyToSubCell, NumericTextBox txtSubcellIndex, MedicalViewerActionType actionType, MedicalViewerBaseAction actionProperties)
        {
            ApplyToCells(viewer, cmbApplyToCell, txtCellIndex, cmbApplyToSubCell, txtSubcellIndex, actionType, actionProperties, null);
        }


        public static void ApplyToCells(MedicalViewer viewer, ComboBox cmbApplyToCell, NumericTextBox txtCellIndex, ComboBox cmbApplyToSubCell, NumericTextBox txtSubcellIndex, MedicalViewerActionType actionType, MedicalViewerBaseAction actionProperties, MyFunctionDelegate myFunction)
        {
            if (cmbApplyToCell == null)
                return;

            if (cmbApplyToCell.Text == "None")
                return;

            int from = 0;
            int to = viewer.Cells.Count;

            switch (cmbApplyToCell.Text)
            {
                case "Custom":
                    if (txtCellIndex.Value >= viewer.Cells.Count)
                        return;
                    from = txtCellIndex.Value;
                    to = txtCellIndex.Value + 1;
                    break;
            }

            int subCellIndex = 0;

            if (txtSubcellIndex != null)
            {
                subCellIndex = txtSubcellIndex.Value;
                switch (cmbApplyToSubCell.Text)
                {
                    case "All":
                        subCellIndex = -1;
                        break;
                    case "Selected":
                        subCellIndex = -2;
                        break;
                }
            }
            else
            {
                subCellIndex = -1;
            }

            int index;
            MedicalViewerMultiCell cell = null;

            for (index = from; index < to; index++)
            {
                cell = (MedicalViewerMultiCell)(viewer.Cells[index]);
                if (cell.Selected || cmbApplyToCell.Text != "Selected")
                {
                    cell.SetActionProperties(actionType, actionProperties, subCellIndex);
                    if (myFunction != null)
                        myFunction(cell, subCellIndex);
                }
            }
        }

        public static void CopyKeysFromGlobalCell(MedicalViewerMultiCell sourceCell, MedicalViewerMultiCell cell, MedicalViewerActionType actionType)
        {
            MedicalViewerKeys keys = sourceCell.GetActionKeys(actionType);
            cell.SetActionKeys(actionType, keys);
        }

        public static void CopyActionPropertiesFromGlobalCell(MedicalViewerMultiCell sourceCell, MedicalViewerMultiCell cell, MedicalViewerActionType actionType)
        {
            MedicalViewerCommonActions baseAction = (MedicalViewerCommonActions)cell.GetActionProperties(actionType);
            MedicalViewerCommonActions virtualBaseAction = (MedicalViewerCommonActions)sourceCell.GetActionProperties(actionType);

            if (baseAction is MedicalViewerCommonActions)
            {
                MedicalViewerCommonActions commonAction = (MedicalViewerCommonActions)baseAction;
                MedicalViewerCommonActions virtualCommonAction = (MedicalViewerCommonActions)virtualBaseAction;
                commonAction.ActionCursor = virtualCommonAction.ActionCursor;
                commonAction.CircularMouseMove = virtualCommonAction.CircularMouseMove;
                commonAction.Sensitivity = virtualCommonAction.Sensitivity;
            }

            cell.SetActionProperties(actionType, baseAction, cell.ActiveSubCell);
        }
        private void _actionsMenuItem_DropDownOpening(object sender, EventArgs e)
        {
#if !LEADTOOLS_V175_OR_LATER
            _miSpyGlass.Visible = 
            _miActionsProbeTool.Visible = 
            _miActionZoomToRectangle.Visible = 
            _miActionClickZoomIn.Visible = 
            _miActionClickZoomOut.Visible =
            _miActionCobbAngle.Visible = false;
#endif //LEADTOOLS_V175_OR_LATER
        }

        private void _miSpyGlassSet_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V175_OR_LATER
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.SpyGlass));
#endif //LEADTOOLS_V175_OR_LATER
        }

        private void _miActionsProbeToolSet_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V175_OR_LATER
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.ProbeTool));
#endif //LEADTOOLS_V175_OR_LATER
        }

        private void _miActionZoomToRectangleSet_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V175_OR_LATER
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.ZoomToRectangle));
#endif //LEADTOOLS_V175_OR_LATER
        }

        private void _miActionClickZoomInSet_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V175_OR_LATER
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.ClickZoomIn));
#endif //LEADTOOLS_V175_OR_LATER
        }

        private void _miActionClickZoomOutSet_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V175_OR_LATER
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.ClickZoomOut));
#endif //LEADTOOLS_V175_OR_LATER
        }

        private void _miActionCobbAngleSet_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V175_OR_LATER
            ShowViewerDialogs(new SetActionDialog(this, MedicalViewerActionType.AnnotationLine));
#endif //LEADTOOLS_V175_OR_LATER
        }

        private AnnLineObject FindAnotherLineObjectToAttach(MedicalViewerSubCell subCell, AnnLineObject lineObject)
        {
            AnnContainer container = subCell.AnnotationContainer;
            int count = subCell.CobbAngles.Count;
            int lastObject = container.Objects.Count - 1;
            AnnLineObject[] list = new AnnLineObject[(count * 2) + 1];
            int index;
            int counter = 0;

            for (index = 0; index < count; index++)
            {
                list[counter++] = subCell.CobbAngles[index].Line1;
                list[counter++] = subCell.CobbAngles[index].Line2;
            }

            AnnObject annObject;
            for (index = lastObject; index >= 0; index--)
            {
                annObject = container.Objects[index];
                if (annObject is AnnLineObject)
                {
                    if (Array.IndexOf(list, annObject) == -1)
                        return (AnnLineObject)annObject;
                }
            }

            return null;
        }

        void cell_AnnotationCreated(object sender, MedicalViewerAnnotationCreatedEventArgs e)
        {
            if (e.AnnotationType == MedicalViewerActionType.AnnotationLine)
            {
                MedicalViewerMultiCell cell = (MedicalViewerMultiCell)(sender);
                AnnContainer container = cell.SubCells[e.SubCellIndex].AnnotationContainer;
                AnnObject annObject = e.Object;
                if (annObject is AnnLineObject)
                {
                    AnnLineObject secondLine = FindAnotherLineObjectToAttach(cell.SubCells[cell.ActiveSubCell], (AnnLineObject)annObject);
                    if (secondLine != null)
                    {
                        cell.SubCells[cell.ActiveSubCell].CobbAngles.Add(new MedicalViewerCobbAngle((AnnLineObject)annObject, secondLine));
                    }
                }
            }
        }

        private void imageInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MedicalViewerMultiCell cell = (MedicalViewerMultiCell)GetSelectedCell();
            if (cell != null)
            {
                if (cell.Image != null)
                {
                    MessageBox.Show(String.Format("Low Bit = {0} \n High Bit {1}\n Signed {2} \nMinimumValue {3} \n MaximumValue {4}", cell.Image.LowBit, cell.Image.HighBit, cell.Image.Signed, cell.Image.MinValue, cell.Image.MaxValue));
                }
            }
        }






#if LEADTOOLS_V175_OR_LATER
        void cell_CellMouseDown(object sender, MedicalViewerCellMouseEventArgs e)
        {
            MedicalViewerMultiCell cell = (MedicalViewerMultiCell)(sender);

            if (cell.Image != null)
            {
                _probeToolImage = cell.Image;
                _probeToolImage.Page = e.SubCellIndex + 1;
            }

        }
        private void AddProbeToolEvents(MedicalViewerCell cell)
        {
            cell.ProbeToolTextChanged += new EventHandler<MedicalViewerProbeToolTextChangedEventArgs>(cell_ProbeToolTextChanged);
            cell.CellMouseDown += new EventHandler<MedicalViewerCellMouseEventArgs>(cell_CellMouseDown);
        }

        void cell_ProbeToolTextChanged(object sender, MedicalViewerProbeToolTextChangedEventArgs e)
        {
            int bitmapX = (int)(e.X);
            int bitmapY = (int)(e.Y);
            string output;

            string value = GetRealPixelValue(_probeToolImage, bitmapX, bitmapY);

            if (value != "")
                output = String.Format("X = {0}, Y = {1} \nValue = {2} \nFrame {3}", (int)e.X, (int)e.Y, value, e.SubCellIndex + 1);
            else
                output = String.Format("X = N/A, Y = N/A \nValue = N/A \nFrame N/A");

            e.Text = output;
        }

        RasterImage _probeToolImage;

        string GetRealPixelValue(RasterImage image, int x, int y)
        {
            LeadPoint bitmapPoint = image.PointToImage(RasterViewPerspective.TopLeft, new LeadPoint(x, y));

            x = bitmapPoint.X;
            y = bitmapPoint.Y;

            if (x >= 0 && y >= 0)
                if ((image.Width >= x) && (image.Height >= y))
                {
                    byte[] Data;
                    Int16 Value;
                    UInt16 uValue;

                    // just work with extended gray scale here
                    if (image.GrayscaleMode != RasterGrayscaleMode.None && image.BitsPerPixel > 8)
                    {
                        Data = image.GetPixelData(y, x);
                        if (image.Signed)
                        {
                            Int16 highBit;
                            if (image.HighBit == 0)
                            {
                                highBit = (Int16)(image.BitsPerPixel - 1);
                            }
                            else
                                highBit = (Int16)image.HighBit;

                            Value = BitConverter.ToInt16(Data, 0);
                            // account for when all allocated bits are not used for image data encoding
                            if ((image.HighBit < (image.BitsPerPixel - 1)) | (image.LowBit > 0))
                            {
                                // actual image low bit is not 0
                                if (image.LowBit != 0)
                                {
                                    Value = (Int16)(Value >> image.LowBit);
                                    highBit = (Int16)(image.HighBit - image.LowBit);
                                }

                                // see if the value is negative 
                                Int16 signLimit;
                                signLimit = (Int16)(Math.Pow(2, highBit + 1) / 2);
                                if (Value >= signLimit)
                                {
                                    Value = (Int16)(Value - (Math.Pow(2, highBit + 1)));
                                }
                            }

                            return Value.ToString();
                        }
                        else
                        {
                            uValue = BitConverter.ToUInt16(Data, 0);
                            // when low bit is not zero
                            if (image.LowBit > 0)
                            {
                                uValue = (UInt16)(uValue >> image.LowBit);
                            }
                            return uValue.ToString();
                        }
                    }
                    else
                    {
                        int R;
                        int G;
                        int B;

                        if (image.BitsPerPixel > 32)
                        {
                            byte[] bit16ComponentData;
                            bit16ComponentData = image.GetPixelData(y, x);
                            R = BitConverter.ToUInt16(bit16ComponentData, 0);
                            G = BitConverter.ToUInt16(bit16ComponentData, 2);
                            B = BitConverter.ToUInt16(bit16ComponentData, 4);
                            return String.Format("{0}, {1}, {2}", R, G, B);
                        }


                        RasterColor PixelColor = image.GetPixelColor(y, x);
                        return String.Format("{0}, {1}, {2}", PixelColor.R, PixelColor.G, PixelColor.B);
                    }

                }
            return "";
        }
#endif //LEADTOOLS_V175_OR_LATER


        public int GetFirstSelectedMultiCellIndex()
        {
            int counter = 0;
            foreach (Control control in _medicalViewer.Cells)
            {
                if (control is MedicalViewerMultiCell)
                {
                    MedicalViewerMultiCell cell = (MedicalViewerMultiCell)control;

                    if (cell.Selected)
                        return counter;

                    counter++;
                }
            }
            return -1;
        }

        private void _menuAddFusion_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V175_OR_LATER

            int cellIndex = GetFirstSelectedMultiCellIndex();

            if (cellIndex == -1)
                return;

            AddFusionImage fusionImage = new AddFusionImage(_medicalViewer, this);
            fusionImage.ShowDialog();
#endif // #if LEADTOOLS_V175_OR_LATER
        }

        private void _menuAdjustFusion_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V175_OR_LATER
            int cellIndex = GetFirstSelectedMultiCellIndex();

            if (cellIndex == -1)
                return;

            AdjustFusionImage fusionImage = new AdjustFusionImage(_medicalViewer, this);
            fusionImage.ShowDialog();
#endif // #if LEADTOOLS_V175_OR_LATER
        }

        private void fusionToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {

#if LEADTOOLS_V175_OR_LATER

            int cellIndex = GetFirstSelectedMultiCellIndex();

            if (cellIndex == -1)
            {
                _menuAddFusion.Enabled =
                _menuAdjustFusion.Enabled = false;
                return;
            }

            MedicalViewerMultiCell cell = (MedicalViewerMultiCell)(_medicalViewer.Cells[cellIndex]);

            if (cell.Frozen)
            {
                _menuAddFusion.Enabled = 
                _menuAdjustFusion.Enabled = false;
            }
            else
            {
                _menuAddFusion.Enabled = true;
                _menuAdjustFusion.Enabled = (cell.SubCells[cell.ActiveSubCell].Fusion.Count != 0);
            }
#else
            _menuAdjustFusion.Enabled = false;
            _menuAddFusion.Enabled = false;
#endif //LEADTOOLS_V175_OR_LATER
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }


    // A class that is derived from System.Windows.Forms.Label control
    public partial class ColorBox : System.Windows.Forms.Label
    {
        private Color _color;

        public ColorBox()
        {
            _color = Color.Transparent;
        }

        public Color BoxColor
        {
            set
            {
                _color = Color.FromArgb(255, value);
                if (this.Enabled)
                    BackColor = _color;
            }
            get
            {
                return Color.FromArgb(0, _color.R, _color.G, _color.B);
            }
        }

        protected override void OnBackColorChanged(EventArgs e)
        {
            base.OnBackColorChanged(e);
            if (BackColor != Color.Transparent)
                _color = BackColor;
        }

        protected override void OnEnabledChanged(EventArgs e)
        {
            base.OnEnabledChanged(e);
            if (this.Enabled)
                BackColor = _color;
            else
                BackColor = Color.Transparent;
        }

        protected override void OnDoubleClick(EventArgs e)
        {
            MainForm.ShowColorDialog(this);
            _color = BackColor;
            base.OnDoubleClick(e);
        }
    }


    // A class that is derieved from TextBox control, that allows only
    // 1) The numeric values.
    // 2) The values that fall within the given range.
    public partial class FNumericTextBox : System.Windows.Forms.TextBox
    {
        private double _maximumAllowed;
        private double _minimumAllowed;
        private string _oldText;

        public FNumericTextBox()
        {
            _maximumAllowed = 1000.0;
            _minimumAllowed = -1000.0;
            _oldText = "";
        }

        [Description("The minimum allowed value to be entered"),
        Category("Allowed Values")]
        public double MinimumAllowed
        {
            set
            {
                _minimumAllowed = value;
            }
            get
            {
                return _minimumAllowed;
            }
        }

        [Description("The maximum allowed value to be entered"),
        Category("Allowed Values")]
        public double MaximumAllowed
        {
            set
            {
                _maximumAllowed = value;
            }
            get
            {
                return _maximumAllowed;
            }
        }

        [Description("The numeric value of the Text box"),
        Category("Current Value")]
        public double Value
        {
            set
            {
                this.Text = value.ToString();
            }
            get
            {
                if (this.Text.Trim() == "")
                    return _minimumAllowed;
                else
                    return Convert.ToDouble(this.Text);
            }
        }

        // Is the entered number within the specified valid range
        private bool IsAllowed(string text)
        {
            bool isAllowed = true;

            try
            {
                double newNumber = Convert.ToDouble(text);
                if ((newNumber > _maximumAllowed) || (newNumber < _minimumAllowed))
                    isAllowed = false;
            }
            catch
            {
                // This happen if the entered value is not a numeric.
                isAllowed = false;
            }

            return isAllowed;
        }

        protected override void OnTextChanged(EventArgs e)
        {
            if (!IsAllowed(this.Text))
            {
                // If this condition doesn't exist, the user will be bugged. (trust me).
                if (_minimumAllowed <= 0)
                    this.Text = _oldText;
            }
            else
                _oldText = this.Text;

            base.OnTextChanged(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            // Increase or decrease the current value by 1 if the user presses the UP or DOWN
            // and test if the new value is allowed
            if ((e.KeyCode == Keys.Up) || (e.KeyCode == Keys.Down))
            {
                double value = Convert.ToDouble(this.Text);

                value = (e.KeyCode == Keys.Up) ? value + 0.1 : value - 0.1;

                if (IsAllowed(value.ToString()))
                    this.Text = value.ToString();
            }

            base.OnKeyDown(e);
        }

        protected override void OnLostFocus(EventArgs e)
        {
            double value = (this.Text.Trim() == "") ? _minimumAllowed : Convert.ToDouble(this.Text);
            if (value < _minimumAllowed)
                this.Text = _minimumAllowed.ToString();

            base.OnLostFocus(e);
        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            // if Enter, Escape, Ctrl or Alt key is pressed, then there is no need to check
            // since the user is not entering a new character...
            if (((Control.ModifierKeys & Keys.Control) == 0) &&
                ((Control.ModifierKeys & Keys.Alt) == 0) &&
                 (e.KeyChar != Convert.ToChar(Keys.Enter)) &&
                 (e.KeyChar != Convert.ToChar(Keys.Escape)) &&
                 (e.KeyChar != Convert.ToChar(Keys.Back)))
            {
                #region Check if the entered character is valid for Numeric format
                // Validate the entered character
                if (!Char.IsNumber(e.KeyChar))
                {

                    #region Check If the user has entered Minus character
                    // Here we check if the user wants to enter the "-" character.
                    if (!((this.Text.IndexOf('-') == -1) && // there is no Minus character
                          (this.SelectionStart == 0) && // the cursor at the begining
                          (_minimumAllowed < 0) && // the minimum allowed accept negative values
                          (e.KeyChar == '-')))  // the character entered was a Minus character
                    {
                        if (!((e.KeyChar == '.') &&
                           (this.Text.IndexOf('.') == -1)))
                            e.KeyChar = Char.MinValue;
                    }
                    #endregion
                }
                #endregion

                if (_minimumAllowed <= 0)
                    #region Checkinng if the value falles within the given range
                    if (e.KeyChar != Char.MinValue)
                    {
                        // Create the string that will be displayed, and check whether it's valid or not.

                        // Remove the selected character(s).
                        string newString = this.Text.Remove(this.SelectionStart, this.SelectionLength);
                        // Insert the new character.
                        newString = newString.Insert(this.SelectionStart, e.KeyChar.ToString());
                        if (!IsAllowed(newString))
                            // the new string is not valid, cancel the whole operation.
                            e.KeyChar = Char.MinValue;
                    }
                    #endregion
            }
            base.OnKeyPress(e);
        }
    }


    public partial class CursorButton : System.Windows.Forms.Button
    {
        private Cursor _buttonCursor;

        public CursorButton()
        {
            _buttonCursor = null;
        }

        [Description("The Cursor"),
        Category("Cursor")]
        public Cursor ButtonCursor
        {
            set
            {
                _buttonCursor = value;
            }
            get
            {
                return _buttonCursor;
            }
        }

        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = @"Cursor files (*.cur) | *.cur";
            openDialog.RestoreDirectory = true;

            if (openDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    _buttonCursor = new System.Windows.Forms.Cursor(openDialog.FileName);
                }
                catch (System.Exception ex)
                {
                    Messager.ShowError(this, ex);
                }

            }
        }

        protected override void OnPaint(PaintEventArgs pevent)
        {
            base.OnPaint(pevent);
            if (_buttonCursor != null)
            {
                int averageWidth = (pevent.ClipRectangle.Width - _buttonCursor.Size.Width) / 2;
                int averageHeight = (pevent.ClipRectangle.Height - _buttonCursor.Size.Height) / 2;

                _buttonCursor.Draw(pevent.Graphics, new Rectangle(averageWidth, averageHeight, _buttonCursor.Size.Width, _buttonCursor.Size.Height));
            }
        }
    }

    // A class that is derieved from TextBox control, that allows only
    // 1) The numeric values.
    // 2) The values that fall within the given range.
    public partial class NumericTextBox : System.Windows.Forms.TextBox
    {
        private int _maximumAllowed;
        private int _minimumAllowed;
        private string _oldText;

        public NumericTextBox()
        {
            _maximumAllowed = 1000;
            _minimumAllowed = -1000;
            _oldText = "";
        }

        [Description("The minimum allowed value to be entered"),
        Category("Allowed Values")]
        public int MinimumAllowed
        {
            set
            {
                _minimumAllowed = value;
            }
            get
            {
                return _minimumAllowed;
            }
        }

        [Description("The maximum allowed value to be entered"),
        Category("Allowed Values")]
        public int MaximumAllowed
        {
            set
            {
                _maximumAllowed = value;
            }
            get
            {
                return _maximumAllowed;
            }
        }

        [Description("The maximum allowed value to be entered"),
        Category("Current Value")]
        public int Value
        {
            set
            {
                this.Text = value.ToString();
            }
            get
            {
                if (this.Text.Trim() == "")
                    return _minimumAllowed;
                else
                    return Convert.ToInt32(this.Text);
            }
        }

        // Is the entered number within the specified valid range
        private bool IsAllowed(string text)
        {
            bool isAllowed = true;

            try
            {
                int newNumber = Convert.ToInt32(text);
                if ((newNumber > _maximumAllowed) || (newNumber < _minimumAllowed))
                    isAllowed = false;
            }
            catch
            {
                // This happen if the entered value is not a numeric.
                isAllowed = false;
            }

            return isAllowed;
        }

        protected override void OnTextChanged(EventArgs e)
        {
            if (!IsAllowed(this.Text))
            {
                if (_minimumAllowed <= 1)
                    this.Text = _oldText;
            }
            else
                _oldText = this.Text;

            base.OnTextChanged(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            // Increase or decrease the current value by 1 if the user presses the UP or DOWN
            // and test if the new value is allowed
            if ((e.KeyCode == Keys.Up) || (e.KeyCode == Keys.Down))
            {
                int value = Convert.ToInt32(this.Text);

                value = (e.KeyCode == Keys.Up) ? value + 1 : value - 1;

                if (IsAllowed(value.ToString()))
                    this.Text = value.ToString();
            }

            base.OnKeyDown(e);
        }

        protected override void OnLostFocus(EventArgs e)
        {
            int value = Convert.ToInt32(this.Text);
            if (value < _minimumAllowed)
                this.Text = _minimumAllowed.ToString();

            base.OnLostFocus(e);
        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            // if Enter, Escape, Ctrl or Alt key is pressed, then there is no need to check
            // since the user is not entering a new character...
            if (((Control.ModifierKeys & Keys.Control) == 0) &&
                ((Control.ModifierKeys & Keys.Alt) == 0) &&
                 (e.KeyChar != Convert.ToChar(Keys.Enter)) &&
                 (e.KeyChar != Convert.ToChar(Keys.Escape)))
            {
                #region Check if the entered character is valid for Numeric format
                // Validate the entered character
                if (!Char.IsNumber(e.KeyChar))
                {

                    #region Check If the user has entered Minus character
                    // Here we check if the user wants to enter the "-" character.
                    if (!((this.Text.IndexOf('-') == -1) && // there is no Minus character
                          (this.SelectionStart == 0) && // the cursor at the begining
                          (_minimumAllowed < 0) && // the minimum allowed accept negative values
                          (e.KeyChar == '-')))  // the character entered was a Minus character
                        e.KeyChar = Char.MinValue;
                    #endregion
                }
                #endregion

                if (_minimumAllowed <= 1)
                    #region Checkinng if the value falles within the given range
                    if (e.KeyChar != Char.MinValue)
                    {
                        // Create the string that will be displayed, and check whether it's valid or not.

                        // Remove the selected character(s).
                        string newString = this.Text.Remove(this.SelectionStart, this.SelectionLength);
                        // Insert the new character.
                        newString = newString.Insert(this.SelectionStart, e.KeyChar.ToString());
                        if (!IsAllowed(newString))
                            // the new string is not valid, cancel the whole operation.
                            e.KeyChar = Char.MinValue;
                    }
                    #endregion
            }
            base.OnKeyPress(e);
        }
    }
}
