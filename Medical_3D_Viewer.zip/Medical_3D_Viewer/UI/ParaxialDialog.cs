using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Leadtools.Medical3D;
using Leadtools.MedicalViewer;

namespace Main3DViewer
{
    public partial class ParaxialDialog : Form
    {
#if LEADTOOLS_V175_OR_LATER
       private int oldLengthValue = 0;
       private int oldDistanceValue = 0;
       MedicalViewerParaxialCutCell _cell;


        public ParaxialDialog(MedicalViewerParaxialCutCell cell)
        {
           InitializeComponent();

           _cell = cell;

           oldLengthValue = (int)_cell.ParaxialLength;
           oldDistanceValue = (int)_cell.ParaxialDistance;
           _textBoxLength.Value = oldLengthValue;
           _textBoxDistance.Value = oldDistanceValue;
        }
#endif //LEADTOOLS_V175_OR_LATER

       private void _btnReset_Click(object sender, EventArgs e)
       {
#if LEADTOOLS_V175_OR_LATER
           _textBoxLength.Value = oldLengthValue;
           _textBoxDistance.Value = oldDistanceValue; 
#endif //LEADTOOLS_V175_OR_LATER
       }

        private void _btnOK_Click(object sender, EventArgs e)
        {
#if LEADTOOLS_V175_OR_LATER
           _cell.BeginUpdate();
           _cell.ParaxialLength = (float)_textBoxLength.Value;
           _cell.ParaxialDistance = (float)_textBoxDistance.Value;
           _cell.EndUpdate();
#endif //LEADTOOLS_V175_OR_LATER
        }
    }
}