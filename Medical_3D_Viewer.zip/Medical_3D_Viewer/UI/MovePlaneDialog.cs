using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Main3DDemo
{
    public partial class MovePlaneDialog : Form
    {
        public MovePlaneDialog()
        {
            InitializeComponent();
        }
    }
}