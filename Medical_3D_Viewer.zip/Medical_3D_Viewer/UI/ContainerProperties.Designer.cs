namespace Main3DViewer
{
    partial class ContainerProperties
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
           this._btnReset = new System.Windows.Forms.Button();
           this._btnCancel = new System.Windows.Forms.Button();
           this._btnOK = new System.Windows.Forms.Button();
           this._btnApply = new System.Windows.Forms.Button();
           this._tabCamera = new System.Windows.Forms.TabPage();
           this._txtCameraFar = new Main3DViewer.NumericTextBox();
           this._txtCameraNear = new Main3DViewer.NumericTextBox();
           this.label2 = new System.Windows.Forms.Label();
           this.label5 = new System.Windows.Forms.Label();
           this._comboBoxProjectionMethod = new System.Windows.Forms.ComboBox();
           this.label1 = new System.Windows.Forms.Label();
           this._tabMPR = new System.Windows.Forms.TabPage();
           this._chkRemoveBackground = new System.Windows.Forms.CheckBox();
           this._chkIntersectionLine = new System.Windows.Forms.CheckBox();
           this._btnIntersectionLineColor = new System.Windows.Forms.Button();
           this._chkFrameBoundary = new System.Windows.Forms.CheckBox();
           this._btnFrameBoundaryColor = new System.Windows.Forms.Button();
           this._lblIntersectionLineColor = new Main3DViewer.ColorBox();
           this._lblFrameBoundaryColor = new Main3DViewer.ColorBox();
           this._tabGeneral = new System.Windows.Forms.TabPage();
           this._lblBackgroundColor = new Main3DViewer.ColorBox();
           this._btnBackgroundColor = new System.Windows.Forms.Button();
           this._chkBoundaryBox = new System.Windows.Forms.CheckBox();
           this._lblBoundaryBoxColor = new Main3DViewer.ColorBox();
           this._btnBoundaryBoxColor = new System.Windows.Forms.Button();
           this._tabControl = new System.Windows.Forms.TabControl();
           this._tabCamera.SuspendLayout();
           this._tabMPR.SuspendLayout();
           this._tabGeneral.SuspendLayout();
           this._tabControl.SuspendLayout();
           this.SuspendLayout();
           // 
           // _btnReset
           // 
           this._btnReset.Location = new System.Drawing.Point(310, 241);
           this._btnReset.Name = "_btnReset";
           this._btnReset.Size = new System.Drawing.Size(90, 33);
           this._btnReset.TabIndex = 18;
           this._btnReset.Text = "&Reset";
           this._btnReset.UseVisualStyleBackColor = true;
           this._btnReset.Click += new System.EventHandler(this._btnReset_Click);
           // 
           // _btnCancel
           // 
           this._btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
           this._btnCancel.Location = new System.Drawing.Point(118, 241);
           this._btnCancel.Name = "_btnCancel";
           this._btnCancel.Size = new System.Drawing.Size(90, 33);
           this._btnCancel.TabIndex = 17;
           this._btnCancel.Text = "&Cancel";
           this._btnCancel.UseVisualStyleBackColor = true;
           // 
           // _btnOK
           // 
           this._btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
           this._btnOK.Location = new System.Drawing.Point(22, 241);
           this._btnOK.Name = "_btnOK";
           this._btnOK.Size = new System.Drawing.Size(90, 33);
           this._btnOK.TabIndex = 16;
           this._btnOK.Text = "&OK";
           this._btnOK.UseVisualStyleBackColor = true;
           this._btnOK.Click += new System.EventHandler(this._btnOK_Click);
           // 
           // _btnApply
           // 
           this._btnApply.Location = new System.Drawing.Point(214, 241);
           this._btnApply.Name = "_btnApply";
           this._btnApply.Size = new System.Drawing.Size(90, 33);
           this._btnApply.TabIndex = 19;
           this._btnApply.Text = "&Apply";
           this._btnApply.UseVisualStyleBackColor = true;
           this._btnApply.Click += new System.EventHandler(this._btnApply_Click);
           // 
           // _tabCamera
           // 
           this._tabCamera.Controls.Add(this._txtCameraFar);
           this._tabCamera.Controls.Add(this._txtCameraNear);
           this._tabCamera.Controls.Add(this.label2);
           this._tabCamera.Controls.Add(this.label5);
           this._tabCamera.Controls.Add(this._comboBoxProjectionMethod);
           this._tabCamera.Controls.Add(this.label1);
           this._tabCamera.Location = new System.Drawing.Point(4, 22);
           this._tabCamera.Name = "_tabCamera";
           this._tabCamera.Size = new System.Drawing.Size(403, 191);
           this._tabCamera.TabIndex = 4;
           this._tabCamera.Text = "Camera";
           this._tabCamera.UseVisualStyleBackColor = true;
           // 
           // _txtCameraFar
           // 
           this._txtCameraFar.Location = new System.Drawing.Point(138, 122);
           this._txtCameraFar.MaximumAllowed = 1000;
           this._txtCameraFar.MinimumAllowed = -1000;
           this._txtCameraFar.Name = "_txtCameraFar";
           this._txtCameraFar.Size = new System.Drawing.Size(50, 20);
           this._txtCameraFar.TabIndex = 31;
           this._txtCameraFar.Text = "0";
           this._txtCameraFar.Value = 0;
           // 
           // _txtCameraNear
           // 
           this._txtCameraNear.Location = new System.Drawing.Point(138, 77);
           this._txtCameraNear.MaximumAllowed = 1000;
           this._txtCameraNear.MinimumAllowed = -1000;
           this._txtCameraNear.Name = "_txtCameraNear";
           this._txtCameraNear.Size = new System.Drawing.Size(50, 20);
           this._txtCameraNear.TabIndex = 30;
           this._txtCameraNear.Text = "0";
           this._txtCameraNear.Value = 0;
           // 
           // label2
           // 
           this.label2.AutoSize = true;
           this.label2.Location = new System.Drawing.Point(60, 125);
           this.label2.Name = "label2";
           this.label2.Size = new System.Drawing.Size(62, 13);
           this.label2.TabIndex = 29;
           this.label2.Text = "&Far Clipping";
           // 
           // label5
           // 
           this.label5.AutoSize = true;
           this.label5.Location = new System.Drawing.Point(53, 80);
           this.label5.Name = "label5";
           this.label5.Size = new System.Drawing.Size(70, 13);
           this.label5.TabIndex = 28;
           this.label5.Text = "&Near Clipping";
           // 
           // _comboBoxProjectionMethod
           // 
           this._comboBoxProjectionMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
           this._comboBoxProjectionMethod.FormattingEnabled = true;
           this._comboBoxProjectionMethod.Items.AddRange(new object[] {
            "Perspective",
            "Orthogonal"});
           this._comboBoxProjectionMethod.Location = new System.Drawing.Point(138, 33);
           this._comboBoxProjectionMethod.Name = "_comboBoxProjectionMethod";
           this._comboBoxProjectionMethod.Size = new System.Drawing.Size(105, 21);
           this._comboBoxProjectionMethod.TabIndex = 27;
           // 
           // label1
           // 
           this.label1.AutoSize = true;
           this.label1.Location = new System.Drawing.Point(29, 37);
           this.label1.Name = "label1";
           this.label1.Size = new System.Drawing.Size(93, 13);
           this.label1.TabIndex = 26;
           this.label1.Text = "&Projection Method";
           // 
           // _tabMPR
           // 
           this._tabMPR.Controls.Add(this._chkRemoveBackground);
           this._tabMPR.Controls.Add(this._chkIntersectionLine);
           this._tabMPR.Controls.Add(this._btnIntersectionLineColor);
           this._tabMPR.Controls.Add(this._chkFrameBoundary);
           this._tabMPR.Controls.Add(this._btnFrameBoundaryColor);
           this._tabMPR.Controls.Add(this._lblIntersectionLineColor);
           this._tabMPR.Controls.Add(this._lblFrameBoundaryColor);
           this._tabMPR.Location = new System.Drawing.Point(4, 22);
           this._tabMPR.Name = "_tabMPR";
           this._tabMPR.Size = new System.Drawing.Size(403, 191);
           this._tabMPR.TabIndex = 3;
           this._tabMPR.Text = "MPR";
           this._tabMPR.UseVisualStyleBackColor = true;
           // 
           // _chkRemoveBackground
           // 
           this._chkRemoveBackground.AutoSize = true;
           this._chkRemoveBackground.Location = new System.Drawing.Point(18, 139);
           this._chkRemoveBackground.Name = "_chkRemoveBackground";
           this._chkRemoveBackground.Size = new System.Drawing.Size(127, 17);
           this._chkRemoveBackground.TabIndex = 19;
           this._chkRemoveBackground.Text = "&Remove Background";
           this._chkRemoveBackground.UseVisualStyleBackColor = true;
           // 
           // _chkIntersectionLine
           // 
           this._chkIntersectionLine.AutoSize = true;
           this._chkIntersectionLine.Location = new System.Drawing.Point(209, 41);
           this._chkIntersectionLine.Name = "_chkIntersectionLine";
           this._chkIntersectionLine.Size = new System.Drawing.Size(134, 17);
           this._chkIntersectionLine.TabIndex = 18;
           this._chkIntersectionLine.Text = "Show &Intersection Line";
           this._chkIntersectionLine.UseVisualStyleBackColor = true;
           this._chkIntersectionLine.CheckedChanged += new System.EventHandler(this._chkIntersectionLine_CheckedChanged);
           // 
           // _btnIntersectionLineColor
           // 
           this._btnIntersectionLineColor.Location = new System.Drawing.Point(209, 72);
           this._btnIntersectionLineColor.Name = "_btnIntersectionLineColor";
           this._btnIntersectionLineColor.Size = new System.Drawing.Size(91, 35);
           this._btnIntersectionLineColor.TabIndex = 16;
           this._btnIntersectionLineColor.Text = "I&ntersection Line Color";
           this._btnIntersectionLineColor.UseVisualStyleBackColor = true;
           this._btnIntersectionLineColor.Click += new System.EventHandler(this._btnIntersectionLineColor_Click);
           // 
           // _chkFrameBoundary
           // 
           this._chkFrameBoundary.AutoSize = true;
           this._chkFrameBoundary.Location = new System.Drawing.Point(17, 41);
           this._chkFrameBoundary.Name = "_chkFrameBoundary";
           this._chkFrameBoundary.Size = new System.Drawing.Size(140, 17);
           this._chkFrameBoundary.TabIndex = 15;
           this._chkFrameBoundary.Text = "Show &Frame boundaries";
           this._chkFrameBoundary.UseVisualStyleBackColor = true;
           this._chkFrameBoundary.CheckedChanged += new System.EventHandler(this._chkFrameBoundary_CheckedChanged);
           // 
           // _btnFrameBoundaryColor
           // 
           this._btnFrameBoundaryColor.Location = new System.Drawing.Point(14, 72);
           this._btnFrameBoundaryColor.Name = "_btnFrameBoundaryColor";
           this._btnFrameBoundaryColor.Size = new System.Drawing.Size(91, 35);
           this._btnFrameBoundaryColor.TabIndex = 13;
           this._btnFrameBoundaryColor.Text = "Show F&rame Boundaries";
           this._btnFrameBoundaryColor.UseVisualStyleBackColor = true;
           this._btnFrameBoundaryColor.Click += new System.EventHandler(this._btnFrameBoundaryColor_Click);
           // 
           // _lblIntersectionLineColor
           // 
           this._lblIntersectionLineColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
           this._lblIntersectionLineColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
           this._lblIntersectionLineColor.BoxColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
           this._lblIntersectionLineColor.Location = new System.Drawing.Point(306, 72);
           this._lblIntersectionLineColor.Name = "_lblIntersectionLineColor";
           this._lblIntersectionLineColor.Size = new System.Drawing.Size(71, 35);
           this._lblIntersectionLineColor.TabIndex = 17;
           // 
           // _lblFrameBoundaryColor
           // 
           this._lblFrameBoundaryColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
           this._lblFrameBoundaryColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
           this._lblFrameBoundaryColor.BoxColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
           this._lblFrameBoundaryColor.Location = new System.Drawing.Point(111, 72);
           this._lblFrameBoundaryColor.Name = "_lblFrameBoundaryColor";
           this._lblFrameBoundaryColor.Size = new System.Drawing.Size(71, 35);
           this._lblFrameBoundaryColor.TabIndex = 14;
           // 
           // _tabGeneral
           // 
           this._tabGeneral.Controls.Add(this._lblBackgroundColor);
           this._tabGeneral.Controls.Add(this._btnBackgroundColor);
           this._tabGeneral.Controls.Add(this._chkBoundaryBox);
           this._tabGeneral.Controls.Add(this._lblBoundaryBoxColor);
           this._tabGeneral.Controls.Add(this._btnBoundaryBoxColor);
           this._tabGeneral.Location = new System.Drawing.Point(4, 22);
           this._tabGeneral.Name = "_tabGeneral";
           this._tabGeneral.Padding = new System.Windows.Forms.Padding(3);
           this._tabGeneral.Size = new System.Drawing.Size(403, 191);
           this._tabGeneral.TabIndex = 0;
           this._tabGeneral.Text = "General";
           this._tabGeneral.UseVisualStyleBackColor = true;
           // 
           // _lblBackgroundColor
           // 
           this._lblBackgroundColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
           this._lblBackgroundColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
           this._lblBackgroundColor.BoxColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
           this._lblBackgroundColor.Location = new System.Drawing.Point(312, 96);
           this._lblBackgroundColor.Name = "_lblBackgroundColor";
           this._lblBackgroundColor.Size = new System.Drawing.Size(71, 35);
           this._lblBackgroundColor.TabIndex = 4;
           // 
           // _btnBackgroundColor
           // 
           this._btnBackgroundColor.Location = new System.Drawing.Point(212, 96);
           this._btnBackgroundColor.Name = "_btnBackgroundColor";
           this._btnBackgroundColor.Size = new System.Drawing.Size(91, 35);
           this._btnBackgroundColor.TabIndex = 3;
           this._btnBackgroundColor.Text = "&Background color";
           this._btnBackgroundColor.UseVisualStyleBackColor = true;
           this._btnBackgroundColor.Click += new System.EventHandler(this._btnBackgroundColor_Click);
           // 
           // _chkBoundaryBox
           // 
           this._chkBoundaryBox.AutoSize = true;
           this._chkBoundaryBox.Location = new System.Drawing.Point(20, 53);
           this._chkBoundaryBox.Name = "_chkBoundaryBox";
           this._chkBoundaryBox.Size = new System.Drawing.Size(122, 17);
           this._chkBoundaryBox.TabIndex = 2;
           this._chkBoundaryBox.Text = "&Show Boundary Box";
           this._chkBoundaryBox.UseVisualStyleBackColor = true;
           this._chkBoundaryBox.CheckedChanged += new System.EventHandler(this._chkBoundaryBox_CheckedChanged);
           // 
           // _lblBoundaryBoxColor
           // 
           this._lblBoundaryBoxColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
           this._lblBoundaryBoxColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
           this._lblBoundaryBoxColor.BoxColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
           this._lblBoundaryBoxColor.Location = new System.Drawing.Point(114, 96);
           this._lblBoundaryBoxColor.Name = "_lblBoundaryBoxColor";
           this._lblBoundaryBoxColor.Size = new System.Drawing.Size(71, 35);
           this._lblBoundaryBoxColor.TabIndex = 1;
           // 
           // _btnBoundaryBoxColor
           // 
           this._btnBoundaryBoxColor.Location = new System.Drawing.Point(17, 96);
           this._btnBoundaryBoxColor.Name = "_btnBoundaryBoxColor";
           this._btnBoundaryBoxColor.Size = new System.Drawing.Size(91, 35);
           this._btnBoundaryBoxColor.TabIndex = 0;
           this._btnBoundaryBoxColor.Text = "Boundary Box Color";
           this._btnBoundaryBoxColor.UseVisualStyleBackColor = true;
           this._btnBoundaryBoxColor.Click += new System.EventHandler(this._btnBoundaryBoxColor_Click);
           // 
           // _tabControl
           // 
           this._tabControl.Controls.Add(this._tabGeneral);
           this._tabControl.Controls.Add(this._tabMPR);
           this._tabControl.Controls.Add(this._tabCamera);
           this._tabControl.Location = new System.Drawing.Point(9, 9);
           this._tabControl.Name = "_tabControl";
           this._tabControl.SelectedIndex = 0;
           this._tabControl.Size = new System.Drawing.Size(411, 217);
           this._tabControl.TabIndex = 0;
           // 
           // ContainerProperties
           // 
           this.AcceptButton = this._btnOK;
           this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
           this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
           this.CancelButton = this._btnCancel;
           this.ClientSize = new System.Drawing.Size(430, 287);
           this.Controls.Add(this._btnApply);
           this.Controls.Add(this._btnReset);
           this.Controls.Add(this._btnCancel);
           this.Controls.Add(this._btnOK);
           this.Controls.Add(this._tabControl);
           this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
           this.MaximizeBox = false;
           this.MinimizeBox = false;
           this.Name = "ContainerProperties";
           this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
           this.Text = "Medical 3D Properties";
           this._tabCamera.ResumeLayout(false);
           this._tabCamera.PerformLayout();
           this._tabMPR.ResumeLayout(false);
           this._tabMPR.PerformLayout();
           this._tabGeneral.ResumeLayout(false);
           this._tabGeneral.PerformLayout();
           this._tabControl.ResumeLayout(false);
           this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button _btnReset;
        private System.Windows.Forms.Button _btnCancel;
       private System.Windows.Forms.Button _btnOK;
        private System.Windows.Forms.Button _btnApply;
       private System.Windows.Forms.TabPage _tabCamera;
       private NumericTextBox _txtCameraFar;
       private NumericTextBox _txtCameraNear;
       private System.Windows.Forms.Label label2;
       private System.Windows.Forms.Label label5;
       private System.Windows.Forms.ComboBox _comboBoxProjectionMethod;
       private System.Windows.Forms.Label label1;
       private System.Windows.Forms.TabPage _tabMPR;
       private System.Windows.Forms.CheckBox _chkRemoveBackground;
       private System.Windows.Forms.CheckBox _chkIntersectionLine;
       private System.Windows.Forms.Button _btnIntersectionLineColor;
       private System.Windows.Forms.CheckBox _chkFrameBoundary;
       private System.Windows.Forms.Button _btnFrameBoundaryColor;
       private ColorBox _lblIntersectionLineColor;
        private ColorBox _lblFrameBoundaryColor;
       private System.Windows.Forms.TabPage _tabGeneral;
       private ColorBox _lblBackgroundColor;
       private System.Windows.Forms.Button _btnBackgroundColor;
       private System.Windows.Forms.CheckBox _chkBoundaryBox;
       private ColorBox _lblBoundaryBoxColor;
       private System.Windows.Forms.Button _btnBoundaryBoxColor;
        private System.Windows.Forms.TabControl _tabControl;
    }
}