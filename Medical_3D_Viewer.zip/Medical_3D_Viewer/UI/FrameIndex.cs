using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Main3DDemo.UI
{
    public partial class FrameIndex : Form
    {
        public FrameIndex()
        {
            InitializeComponent();
        }
    }
}