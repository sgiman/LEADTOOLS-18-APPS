namespace Main3DViewer
{
    partial class CheckUtilityDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._btnOK = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this._lblDepthOperation = new Main3DViewer.CheckLabel();
            this._lblBlending = new Main3DViewer.CheckLabel();
            this._lblBackBuffer = new Main3DViewer.CheckLabel();
            this._lblTexturing = new Main3DViewer.CheckLabel();
            this._lblHardwareShaderAvailable = new Main3DViewer.CheckLabel();
            this._lblPixelShaderAvailable = new Main3DViewer.CheckLabel();
            this._lblVertexShaderAvailable = new Main3DViewer.CheckLabel();
            this._lblDirectXVersionAvailable = new Main3DViewer.CheckLabel();
            this.label10 = new System.Windows.Forms.Label();
            this._label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this._lblMaximum3D = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this._lblMaximum2D = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this._lblSharedGPU = new System.Windows.Forms.Label();
            this._lblDirectXVersion = new System.Windows.Forms.Label();
            this._lblDedicatedGPU = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this._lblVertexShaderSuccess = new Main3DViewer.CheckLabel();
            this._lblPixelShaderSuccess = new Main3DViewer.CheckLabel();
            this._lblDirectXVersionSuccess = new Main3DViewer.CheckLabel();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // _btnOK
            // 
            this._btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this._btnOK.Location = new System.Drawing.Point(246, 333);
            this._btnOK.Name = "_btnOK";
            this._btnOK.Size = new System.Drawing.Size(79, 25);
            this._btnOK.TabIndex = 34;
            this._btnOK.Text = "&OK";
            this._btnOK.UseVisualStyleBackColor = true;
            this._btnOK.Click += new System.EventHandler(this._btnOK_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this._lblDepthOperation);
            this.groupBox1.Controls.Add(this._lblBlending);
            this.groupBox1.Controls.Add(this._lblBackBuffer);
            this.groupBox1.Controls.Add(this._lblTexturing);
            this.groupBox1.Controls.Add(this._lblHardwareShaderAvailable);
            this.groupBox1.Controls.Add(this._lblPixelShaderAvailable);
            this.groupBox1.Controls.Add(this._lblVertexShaderAvailable);
            this.groupBox1.Controls.Add(this._lblDirectXVersionAvailable);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this._label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(266, 315);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Compatability Check";
            // 
            // _lblDepthOperation
            // 
            this._lblDepthOperation.BackColor = System.Drawing.SystemColors.Control;
            this._lblDepthOperation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblDepthOperation.Checked = false;
            this._lblDepthOperation.Location = new System.Drawing.Point(208, 260);
            this._lblDepthOperation.Name = "_lblDepthOperation";
            this._lblDepthOperation.Size = new System.Drawing.Size(40, 21);
            this._lblDepthOperation.TabIndex = 17;
            this._lblDepthOperation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _lblBlending
            // 
            this._lblBlending.BackColor = System.Drawing.SystemColors.Control;
            this._lblBlending.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblBlending.Checked = false;
            this._lblBlending.Location = new System.Drawing.Point(208, 228);
            this._lblBlending.Name = "_lblBlending";
            this._lblBlending.Size = new System.Drawing.Size(40, 21);
            this._lblBlending.TabIndex = 16;
            this._lblBlending.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _lblBackBuffer
            // 
            this._lblBackBuffer.BackColor = System.Drawing.SystemColors.Control;
            this._lblBackBuffer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblBackBuffer.Checked = false;
            this._lblBackBuffer.Location = new System.Drawing.Point(208, 195);
            this._lblBackBuffer.Name = "_lblBackBuffer";
            this._lblBackBuffer.Size = new System.Drawing.Size(40, 21);
            this._lblBackBuffer.TabIndex = 15;
            this._lblBackBuffer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _lblTexturing
            // 
            this._lblTexturing.BackColor = System.Drawing.SystemColors.Control;
            this._lblTexturing.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblTexturing.Checked = false;
            this._lblTexturing.Location = new System.Drawing.Point(208, 163);
            this._lblTexturing.Name = "_lblTexturing";
            this._lblTexturing.Size = new System.Drawing.Size(40, 21);
            this._lblTexturing.TabIndex = 14;
            this._lblTexturing.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _lblHardwareShaderAvailable
            // 
            this._lblHardwareShaderAvailable.BackColor = System.Drawing.SystemColors.Control;
            this._lblHardwareShaderAvailable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblHardwareShaderAvailable.Checked = false;
            this._lblHardwareShaderAvailable.Location = new System.Drawing.Point(208, 131);
            this._lblHardwareShaderAvailable.Name = "_lblHardwareShaderAvailable";
            this._lblHardwareShaderAvailable.Size = new System.Drawing.Size(40, 21);
            this._lblHardwareShaderAvailable.TabIndex = 13;
            this._lblHardwareShaderAvailable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _lblPixelShaderAvailable
            // 
            this._lblPixelShaderAvailable.BackColor = System.Drawing.SystemColors.Control;
            this._lblPixelShaderAvailable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblPixelShaderAvailable.Checked = false;
            this._lblPixelShaderAvailable.Location = new System.Drawing.Point(208, 99);
            this._lblPixelShaderAvailable.Name = "_lblPixelShaderAvailable";
            this._lblPixelShaderAvailable.Size = new System.Drawing.Size(40, 21);
            this._lblPixelShaderAvailable.TabIndex = 12;
            this._lblPixelShaderAvailable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _lblVertexShaderAvailable
            // 
            this._lblVertexShaderAvailable.BackColor = System.Drawing.SystemColors.Control;
            this._lblVertexShaderAvailable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblVertexShaderAvailable.Checked = false;
            this._lblVertexShaderAvailable.Location = new System.Drawing.Point(208, 67);
            this._lblVertexShaderAvailable.Name = "_lblVertexShaderAvailable";
            this._lblVertexShaderAvailable.Size = new System.Drawing.Size(40, 21);
            this._lblVertexShaderAvailable.TabIndex = 11;
            this._lblVertexShaderAvailable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _lblDirectXVersionAvailable
            // 
            this._lblDirectXVersionAvailable.BackColor = System.Drawing.SystemColors.Control;
            this._lblDirectXVersionAvailable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblDirectXVersionAvailable.Checked = false;
            this._lblDirectXVersionAvailable.Location = new System.Drawing.Point(208, 36);
            this._lblDirectXVersionAvailable.Name = "_lblDirectXVersionAvailable";
            this._lblDirectXVersionAvailable.Size = new System.Drawing.Size(40, 21);
            this._lblDirectXVersionAvailable.TabIndex = 10;
            this._lblDirectXVersionAvailable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(18, 265);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(131, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Depth Operation Available";
            // 
            // _label9
            // 
            this._label9.AutoSize = true;
            this._label9.Location = new System.Drawing.Point(18, 233);
            this._label9.Name = "_label9";
            this._label9.Size = new System.Drawing.Size(94, 13);
            this._label9.TabIndex = 8;
            this._label9.Text = "Blending Available";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(18, 201);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(156, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Back-Buffer Texturing Available";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 169);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Texturing Available";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 137);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Hardware Shader Available";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Pixel Shader Available";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Vertex Shader Available";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Is DirectX Version Valid ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this._lblMaximum3D);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this._lblMaximum2D);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this._lblSharedGPU);
            this.groupBox2.Controls.Add(this._lblDirectXVersion);
            this.groupBox2.Controls.Add(this._lblDedicatedGPU);
            this.groupBox2.Location = new System.Drawing.Point(285, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(297, 184);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Hardware Features";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(23, 155);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(159, 13);
            this.label22.TabIndex = 13;
            this.label22.Text = "Maximum 3D Texture Dimension";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(23, 123);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(159, 13);
            this.label23.TabIndex = 12;
            this.label23.Text = "Maximum 2D Texture Dimension";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(23, 91);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(130, 13);
            this.label24.TabIndex = 11;
            this.label24.Text = "Shared GPU Memory Size";
            // 
            // _lblMaximum3D
            // 
            this._lblMaximum3D.BackColor = System.Drawing.SystemColors.Control;
            this._lblMaximum3D.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblMaximum3D.Location = new System.Drawing.Point(202, 153);
            this._lblMaximum3D.Name = "_lblMaximum3D";
            this._lblMaximum3D.Size = new System.Drawing.Size(68, 21);
            this._lblMaximum3D.TabIndex = 22;
            this._lblMaximum3D.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(23, 59);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(145, 13);
            this.label25.TabIndex = 10;
            this.label25.Text = "Dedicated GPU Memory Size";
            // 
            // _lblMaximum2D
            // 
            this._lblMaximum2D.BackColor = System.Drawing.SystemColors.Control;
            this._lblMaximum2D.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblMaximum2D.Location = new System.Drawing.Point(202, 121);
            this._lblMaximum2D.Name = "_lblMaximum2D";
            this._lblMaximum2D.Size = new System.Drawing.Size(68, 21);
            this._lblMaximum2D.TabIndex = 21;
            this._lblMaximum2D.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(23, 27);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(80, 13);
            this.label34.TabIndex = 1;
            this.label34.Text = "DirectX Version";
            // 
            // _lblSharedGPU
            // 
            this._lblSharedGPU.BackColor = System.Drawing.SystemColors.Control;
            this._lblSharedGPU.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblSharedGPU.Location = new System.Drawing.Point(202, 89);
            this._lblSharedGPU.Name = "_lblSharedGPU";
            this._lblSharedGPU.Size = new System.Drawing.Size(68, 21);
            this._lblSharedGPU.TabIndex = 20;
            this._lblSharedGPU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _lblDirectXVersion
            // 
            this._lblDirectXVersion.BackColor = System.Drawing.SystemColors.Control;
            this._lblDirectXVersion.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblDirectXVersion.Location = new System.Drawing.Point(202, 26);
            this._lblDirectXVersion.Name = "_lblDirectXVersion";
            this._lblDirectXVersion.Size = new System.Drawing.Size(68, 21);
            this._lblDirectXVersion.TabIndex = 18;
            this._lblDirectXVersion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _lblDedicatedGPU
            // 
            this._lblDedicatedGPU.BackColor = System.Drawing.SystemColors.Control;
            this._lblDedicatedGPU.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblDedicatedGPU.Location = new System.Drawing.Point(202, 57);
            this._lblDedicatedGPU.Name = "_lblDedicatedGPU";
            this._lblDedicatedGPU.Size = new System.Drawing.Size(68, 21);
            this._lblDedicatedGPU.TabIndex = 19;
            this._lblDedicatedGPU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.SystemColors.Control;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label18.Location = new System.Drawing.Point(163, 61);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(87, 21);
            this.label18.TabIndex = 19;
            this.label18.Text = "2.0";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.SystemColors.Control;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label17.Location = new System.Drawing.Point(163, 30);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(87, 21);
            this.label17.TabIndex = 18;
            this.label17.Text = "9.0c or Higher";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.Control;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label16.Location = new System.Drawing.Point(163, 93);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(87, 21);
            this.label16.TabIndex = 20;
            this.label16.Text = "2.0";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(23, 31);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(88, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "DirectX Required";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(23, 63);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(112, 13);
            this.label12.TabIndex = 10;
            this.label12.Text = "Pixel Shader Required";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(23, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Vertex Shader Required";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this._lblVertexShaderSuccess);
            this.groupBox3.Controls.Add(this._lblPixelShaderSuccess);
            this.groupBox3.Controls.Add(this._lblDirectXVersionSuccess);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Location = new System.Drawing.Point(285, 203);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(297, 124);
            this.groupBox3.TabIndex = 35;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Basic Required Features";
            // 
            // _lblVertexShaderSuccess
            // 
            this._lblVertexShaderSuccess.BackColor = System.Drawing.SystemColors.Control;
            this._lblVertexShaderSuccess.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblVertexShaderSuccess.Checked = false;
            this._lblVertexShaderSuccess.Location = new System.Drawing.Point(256, 94);
            this._lblVertexShaderSuccess.Name = "_lblVertexShaderSuccess";
            this._lblVertexShaderSuccess.Size = new System.Drawing.Size(27, 21);
            this._lblVertexShaderSuccess.TabIndex = 22;
            this._lblVertexShaderSuccess.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _lblPixelShaderSuccess
            // 
            this._lblPixelShaderSuccess.BackColor = System.Drawing.SystemColors.Control;
            this._lblPixelShaderSuccess.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblPixelShaderSuccess.Checked = false;
            this._lblPixelShaderSuccess.Location = new System.Drawing.Point(256, 62);
            this._lblPixelShaderSuccess.Name = "_lblPixelShaderSuccess";
            this._lblPixelShaderSuccess.Size = new System.Drawing.Size(27, 21);
            this._lblPixelShaderSuccess.TabIndex = 21;
            this._lblPixelShaderSuccess.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _lblDirectXVersionSuccess
            // 
            this._lblDirectXVersionSuccess.BackColor = System.Drawing.SystemColors.Control;
            this._lblDirectXVersionSuccess.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._lblDirectXVersionSuccess.Checked = false;
            this._lblDirectXVersionSuccess.Location = new System.Drawing.Point(256, 30);
            this._lblDirectXVersionSuccess.Name = "_lblDirectXVersionSuccess";
            this._lblDirectXVersionSuccess.Size = new System.Drawing.Size(27, 21);
            this._lblDirectXVersionSuccess.TabIndex = 18;
            this._lblDirectXVersionSuccess.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CheckUtilityDialog
            // 
            this.AcceptButton = this._btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this._btnOK;
            this.ClientSize = new System.Drawing.Size(591, 369);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this._btnOK);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CheckUtilityDialog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Check Utility";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button _btnOK;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label _label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private CheckLabel _lblDirectXVersionAvailable;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label34;
        private CheckLabel _lblBlending;
        private CheckLabel _lblBackBuffer;
        private CheckLabel _lblTexturing;
        private CheckLabel _lblHardwareShaderAvailable;
        private CheckLabel _lblPixelShaderAvailable;
        private CheckLabel _lblVertexShaderAvailable;
        private CheckLabel _lblDepthOperation;
        private System.Windows.Forms.Label _lblMaximum3D;
        private System.Windows.Forms.Label _lblMaximum2D;
        private System.Windows.Forms.Label _lblSharedGPU;
        private System.Windows.Forms.Label _lblDirectXVersion;
        private System.Windows.Forms.Label _lblDedicatedGPU;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox3;
        private CheckLabel _lblDirectXVersionSuccess;
        private CheckLabel _lblVertexShaderSuccess;
        private CheckLabel _lblPixelShaderSuccess;
    }
}