namespace Main3DViewer
{
   partial class ParaxialDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
           this._btnReset = new System.Windows.Forms.Button();
           this._btnCancel = new System.Windows.Forms.Button();
           this._btnOK = new System.Windows.Forms.Button();
           this.groupBox1 = new System.Windows.Forms.GroupBox();
           this._lengthLbl = new System.Windows.Forms.Label();
           this._distanceLbl = new System.Windows.Forms.Label();
           this._textBoxLength = new Main3DViewer.NumericTextBox();
           this._textBoxDistance = new Main3DViewer.NumericTextBox();
           this.groupBox1.SuspendLayout();
           this.SuspendLayout();
           // 
           // _btnReset
           // 
           this._btnReset.Location = new System.Drawing.Point(168, 128);
           this._btnReset.Name = "_btnReset";
           this._btnReset.Size = new System.Drawing.Size(61, 33);
           this._btnReset.TabIndex = 19;
           this._btnReset.Text = "&Reset";
           this._btnReset.UseVisualStyleBackColor = true;
           this._btnReset.Click += new System.EventHandler(this._btnReset_Click);
           // 
           // _btnCancel
           // 
           this._btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
           this._btnCancel.Location = new System.Drawing.Point(98, 128);
           this._btnCancel.Name = "_btnCancel";
           this._btnCancel.Size = new System.Drawing.Size(64, 33);
           this._btnCancel.TabIndex = 18;
           this._btnCancel.Text = "&Cancel";
           this._btnCancel.UseVisualStyleBackColor = true;
           // 
           // _btnOK
           // 
           this._btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
           this._btnOK.Location = new System.Drawing.Point(28, 128);
           this._btnOK.Name = "_btnOK";
           this._btnOK.Size = new System.Drawing.Size(64, 33);
           this._btnOK.TabIndex = 17;
           this._btnOK.Text = "&OK";
           this._btnOK.UseVisualStyleBackColor = true;
           this._btnOK.Click += new System.EventHandler(this._btnOK_Click);
           // 
           // groupBox1
           // 
           this.groupBox1.Controls.Add(this._lengthLbl);
           this.groupBox1.Controls.Add(this._distanceLbl);
           this.groupBox1.Controls.Add(this._textBoxLength);
           this.groupBox1.Controls.Add(this._textBoxDistance);
           this.groupBox1.Location = new System.Drawing.Point(12, 10);
           this.groupBox1.Name = "groupBox1";
           this.groupBox1.Size = new System.Drawing.Size(237, 105);
           this.groupBox1.TabIndex = 16;
           this.groupBox1.TabStop = false;
           this.groupBox1.Text = "&Parameters";
           // 
           // _lengthLbl
           // 
           this._lengthLbl.AutoSize = true;
           this._lengthLbl.Location = new System.Drawing.Point(35, 69);
           this._lengthLbl.Name = "_lengthLbl";
           this._lengthLbl.Size = new System.Drawing.Size(81, 13);
           this._lengthLbl.TabIndex = 14;
           this._lengthLbl.Text = "&Paraxial Length";
           // 
           // _distanceLbl
           // 
           this._distanceLbl.AutoSize = true;
           this._distanceLbl.Location = new System.Drawing.Point(35, 29);
           this._distanceLbl.Name = "_distanceLbl";
           this._distanceLbl.Size = new System.Drawing.Size(89, 13);
           this._distanceLbl.TabIndex = 13;
           this._distanceLbl.Text = "Paraxial Distance";
           // 
           // _textBoxLength
           // 
           this._textBoxLength.Location = new System.Drawing.Point(138, 66);
           this._textBoxLength.MaximumAllowed = 1000;
           this._textBoxLength.MinimumAllowed = 1;
           this._textBoxLength.Name = "_textBoxLength";
           this._textBoxLength.Size = new System.Drawing.Size(50, 20);
           this._textBoxLength.TabIndex = 9;
           this._textBoxLength.Value = 1;
           // 
           // _textBoxDistance
           // 
           this._textBoxDistance.Location = new System.Drawing.Point(139, 26);
           this._textBoxDistance.MaximumAllowed = 1000;
           this._textBoxDistance.MinimumAllowed = 1;
           this._textBoxDistance.Name = "_textBoxDistance";
           this._textBoxDistance.Size = new System.Drawing.Size(50, 20);
           this._textBoxDistance.TabIndex = 6;
           this._textBoxDistance.Text = "1";
           this._textBoxDistance.Value = 1;
           // 
           // ParaxialDialog
           // 
           this.AcceptButton = this._btnOK;
           this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
           this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
           this.CancelButton = this._btnCancel;
           this.ClientSize = new System.Drawing.Size(258, 172);
           this.Controls.Add(this._btnReset);
           this.Controls.Add(this._btnCancel);
           this.Controls.Add(this._btnOK);
           this.Controls.Add(this.groupBox1);
           this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
           this.MaximizeBox = false;
           this.MinimizeBox = false;
           this.Name = "ParaxialDialog";
           this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
           this.Text = "Paraxial Dialog";
           this.groupBox1.ResumeLayout(false);
           this.groupBox1.PerformLayout();
           this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button _btnReset;
        private System.Windows.Forms.Button _btnCancel;
        private System.Windows.Forms.Button _btnOK;
        private System.Windows.Forms.GroupBox groupBox1;
        private NumericTextBox _textBoxLength;
        private NumericTextBox _textBoxDistance;
        private System.Windows.Forms.Label _lengthLbl;
        private System.Windows.Forms.Label _distanceLbl;
    }
}