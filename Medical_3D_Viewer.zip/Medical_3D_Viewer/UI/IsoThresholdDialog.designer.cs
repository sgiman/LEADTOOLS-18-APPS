namespace Main3DViewer
{
   partial class IsoThresholdDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
           this.label4 = new System.Windows.Forms.Label();
           this._btnReset = new System.Windows.Forms.Button();
           this._btnOK = new System.Windows.Forms.Button();
           this._btnCancel = new System.Windows.Forms.Button();
           this.groupBox1 = new System.Windows.Forms.GroupBox();
           this._trackThreshold = new System.Windows.Forms.TrackBar();
           this._btnApply = new System.Windows.Forms.Button();
           this._textBoxThreshold = new Main3DViewer.NumericTextBox();
           this.groupBox1.SuspendLayout();
           ((System.ComponentModel.ISupportInitialize)(this._trackThreshold)).BeginInit();
           this.SuspendLayout();
           // 
           // label4
           // 
           this.label4.AutoSize = true;
           this.label4.Location = new System.Drawing.Point(2, 27);
           this.label4.Name = "label4";
           this.label4.Size = new System.Drawing.Size(54, 13);
           this.label4.TabIndex = 37;
           this.label4.Text = "&Threshold";
           // 
           // _btnReset
           // 
           this._btnReset.Location = new System.Drawing.Point(194, 96);
           this._btnReset.Name = "_btnReset";
           this._btnReset.Size = new System.Drawing.Size(55, 30);
           this._btnReset.TabIndex = 36;
           this._btnReset.Text = "&Reset";
           this._btnReset.UseVisualStyleBackColor = true;
           this._btnReset.Click += new System.EventHandler(this._btnReset_Click);
           // 
           // _btnOK
           // 
           this._btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
           this._btnOK.Location = new System.Drawing.Point(11, 96);
           this._btnOK.Name = "_btnOK";
           this._btnOK.Size = new System.Drawing.Size(55, 30);
           this._btnOK.TabIndex = 34;
           this._btnOK.Text = "&OK";
           this._btnOK.UseVisualStyleBackColor = true;
           this._btnOK.Click += new System.EventHandler(this._btnOK_Click);
           // 
           // _btnCancel
           // 
           this._btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
           this._btnCancel.Location = new System.Drawing.Point(131, 96);
           this._btnCancel.Name = "_btnCancel";
           this._btnCancel.Size = new System.Drawing.Size(55, 30);
           this._btnCancel.TabIndex = 35;
           this._btnCancel.Text = "&Cancel";
           this._btnCancel.UseVisualStyleBackColor = true;
           this._btnCancel.Click += new System.EventHandler(this._btnCancel_Click);
           // 
           // groupBox1
           // 
           this.groupBox1.Controls.Add(this.label4);
           this.groupBox1.Controls.Add(this._textBoxThreshold);
           this.groupBox1.Controls.Add(this._trackThreshold);
           this.groupBox1.Location = new System.Drawing.Point(12, 12);
           this.groupBox1.Name = "groupBox1";
           this.groupBox1.Size = new System.Drawing.Size(236, 68);
           this.groupBox1.TabIndex = 33;
           this.groupBox1.TabStop = false;
           this.groupBox1.Text = "&Parameter";
           // 
           // _trackThreshold
           // 
           this._trackThreshold.Location = new System.Drawing.Point(53, 22);
           this._trackThreshold.Maximum = 255;
           this._trackThreshold.Minimum = 1;
           this._trackThreshold.Name = "_trackThreshold";
           this._trackThreshold.Size = new System.Drawing.Size(135, 45);
           this._trackThreshold.TabIndex = 31;
           this._trackThreshold.TickFrequency = 0;
           this._trackThreshold.TickStyle = System.Windows.Forms.TickStyle.None;
           this._trackThreshold.Value = 100;
           this._trackThreshold.ValueChanged += new System.EventHandler(this._trackBarOpacity_Scroll);
           // 
           // _btnApply
           // 
           this._btnApply.Location = new System.Drawing.Point(72, 96);
           this._btnApply.Name = "_btnApply";
           this._btnApply.Size = new System.Drawing.Size(55, 30);
           this._btnApply.TabIndex = 37;
           this._btnApply.Text = "&Apply";
           this._btnApply.UseVisualStyleBackColor = true;
           this._btnApply.Click += new System.EventHandler(this._btnApply_Click);
           // 
           // _textBoxThreshold
           // 
           this._textBoxThreshold.Location = new System.Drawing.Point(192, 24);
           this._textBoxThreshold.MaximumAllowed = 255;
           this._textBoxThreshold.MinimumAllowed = 1;
           this._textBoxThreshold.Name = "_textBoxThreshold";
           this._textBoxThreshold.Size = new System.Drawing.Size(37, 20);
           this._textBoxThreshold.TabIndex = 33;
           this._textBoxThreshold.Text = "1";
           this._textBoxThreshold.Value = 1;
           this._textBoxThreshold.TextChanged += new System.EventHandler(this._textBoxOpacity_TextChanged);
           // 
           // IsoThresholdDialog
           // 
           this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
           this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
           this.ClientSize = new System.Drawing.Size(261, 138);
           this.Controls.Add(this._btnApply);
           this.Controls.Add(this._btnReset);
           this.Controls.Add(this._btnOK);
           this.Controls.Add(this._btnCancel);
           this.Controls.Add(this.groupBox1);
           this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
           this.MaximizeBox = false;
           this.MinimizeBox = false;
           this.Name = "IsoThresholdDialog";
           this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
           this.Text = "Iso Threshold Dialog";
           this.groupBox1.ResumeLayout(false);
           this.groupBox1.PerformLayout();
           ((System.ComponentModel.ISupportInitialize)(this._trackThreshold)).EndInit();
           this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TrackBar _trackThreshold;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button _btnReset;
        private NumericTextBox _textBoxThreshold;
        private System.Windows.Forms.Button _btnOK;
        private System.Windows.Forms.Button _btnCancel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button _btnApply;
    }
}